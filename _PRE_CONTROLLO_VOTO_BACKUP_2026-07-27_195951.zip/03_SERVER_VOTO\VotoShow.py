"""
VotoShow.py
Server di voto/richiesta canzoni per gli ospiti dello show, in esecuzione
DURANTE lo show sulla rete ospiti. Usa solo la libreria standard di
Python (http.server, json, html, uuid): nessuna dipendenza esterna, per
restare il piu' leggero e stabile possibile mentre lo show e' live.

Fase 2: se [TRIGGER_LOR] Abilita_Controllo_LOR = True nell'ini, un thread
separato (ponte_lor) controlla la REST API di LOR, aspetta la fine della
canzone in corso, fa partire quella piu' votata e azzera il turno. Se
disabilitato, si torna al comportamento Fase 1: solo voto/classifica,
reset manuale dalla pagina /risultati.

Pagine:
  GET  /              pagina di voto per gli ospiti
  GET  /risultati      pagina classifica per l'operatore (non collegata
                       dalla pagina ospiti)
  GET  /copertine/...  immagini di copertina
  POST /vota           registra/aggiorna il voto del dispositivo corrente
  POST /reset           azzera i voti per iniziare un nuovo turno
"""

import configparser
import html
import json
import logging
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from collections import deque
from datetime import datetime
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from traduzioni import LINGUA_DEFAULT, testo

INTERVALLO_POLLING_LOR_SECONDI = 3
SOGLIA_FINE_CANZONE_SECONDI = 6
NUMERO_TURNI_RAFFREDDAMENTO = 3  # una sequenza appena vinta non puo' rivincere per questi turni
NOME_COOKIE_LINGUA = "lingua"
LINGUE_VALIDE = ("it", "en")
NOME_COOKIE_ADMIN = "token_admin"
INTERVALLO_MINIMO_RICHIESTA_SECONDI = 2.0  # rate limiting: min secondi tra due POST dello stesso IP

SCRIPT_DIR = Path(__file__).resolve().parent
CARTELLA_AUTOMAZIONE = SCRIPT_DIR.parent / "01_AUTOMAZIONE"
CONFIG_PATH = CARTELLA_AUTOMAZIONE / "CONFIGURAZIONE_SHOW.ini"
FILE_CATALOGO = SCRIPT_DIR / "catalogo_canzoni.json"
CARTELLA_COPERTINE = SCRIPT_DIR / "COPERTINE"
CARTELLA_LOG = SCRIPT_DIR / "LOG"
FILE_STATO_VOTI = CARTELLA_LOG / "voti_stato.json"

NOME_COOKIE_ELETTORE = "id_elettore"

# Stato in memoria del turno di voto corrente: {id_elettore: id_canzone}
voti_correnti: dict[str, str] = {}
catalogo_canzoni: list[dict] = []

# Coda salvata dall'ultimo turno con richieste chiare (vedi ponte_lor):
# condivisa col server HTTP solo per mostrarla nella pagina risultati,
# il ponte con LOR e' l'unico che la scrive davvero.
coda_classifica_condivisa: list[dict] = []

# Classifica del turno che ha determinato la sequenza ATTUALMENTE in
# onda (vincitore + resto), catturata nel momento esatto in cui e' stata
# decisa - condivisa solo per mostrarla nella pagina risultati.
classifica_vincente_condivisa: list[dict] = []

# Rate limiting per IP sulle richieste POST (voti/reset/login): ultimo
# istante (time.monotonic) in cui ogni IP ha effettuato una richiesta.
_ultima_richiesta_per_ip: dict[str, float] = {}
_lock_rate_limit = threading.Lock()

# voti_correnti e' letto/scritto da molti thread insieme (un thread per
# richiesta HTTP, piu' il thread ponte_lor): senza questo lock, un voto
# che arriva mentre e' in corso il calcolo della classifica puo' far
# esplodere l'iterazione del dizionario ("dictionary changed size during
# iteration") - un crash inutile con tanti ospiti che votano insieme.
_lock_voti = threading.Lock()

MAX_LUNGHEZZA_CORPO_POST = 4096  # id canzone e password admin sono corti: oltre questo e' anomalo
MAX_CONNESSIONI_CONTEMPORANEE = 40  # oltre questo tetto il PC dello show va protetto, non il voto
TIMEOUT_SOCKET_SECONDI = 10  # chiude connessioni aperte che non mandano dati (slowloris)


def _sanifica_testo_pubblico(valore: str) -> str:
    """Rimuove caratteri che non devono comparire in un dato inviato dal
    pubblico (id canzone, ecc.), per non lasciar passare frammenti di
    markup/HTML verso il resto del programma."""
    for carattere in ("<", ">", "/"):
        valore = valore.replace(carattere, "")
    return valore


# ----------------------------------------------------------------------
# Avvio: logging e caricamento dati
# ----------------------------------------------------------------------
def configura_logging() -> logging.Logger:
    CARTELLA_LOG.mkdir(parents=True, exist_ok=True)
    percorso_log = CARTELLA_LOG / f"VotoShow_{datetime.now():%Y%m%d}.log"

    logger = logging.getLogger("VotoShow")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    formato = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    handler_file = logging.FileHandler(percorso_log, encoding="utf-8")
    handler_file.setFormatter(formato)
    logger.addHandler(handler_file)

    handler_console = logging.StreamHandler(sys.stdout)
    handler_console.setFormatter(formato)
    logger.addHandler(handler_console)

    return logger


def leggi_porta_server(logger: logging.Logger) -> int:
    parser = configparser.ConfigParser()
    letti = parser.read(CONFIG_PATH, encoding="utf-8")
    if not letti:
        logger.warning("CONFIGURAZIONE_SHOW.ini non trovato, uso porta di default 8080")
        return 8080
    return parser.getint("VOTO", "Porta_Server", fallback=8080)


def leggi_token_admin(logger: logging.Logger) -> str:
    """Password per /risultati e /reset. Vuota = nessuna protezione."""
    parser = configparser.ConfigParser()
    letti = parser.read(CONFIG_PATH, encoding="utf-8")
    if not letti:
        return ""
    return parser.get("VOTO", "Token_Amministratore", fallback="").strip()


def leggi_configurazione_lor(logger: logging.Logger):
    """Legge [TRIGGER_LOR] (se/come collegarsi a LOR) e [SEQUENZE_LOR]
    (nome esatto di ogni canzone come compare in LOR, usato per
    mainSequences/playNext). Ritorna (abilitato, porta_api, mappa_nomi_lor)."""
    parser = configparser.ConfigParser()
    letti = parser.read(CONFIG_PATH, encoding="utf-8")
    if not letti or "TRIGGER_LOR" not in parser:
        logger.info("[LOR] Sezione [TRIGGER_LOR] non trovata: integrazione con LOR disattivata")
        return False, 8001, {}

    sezione = parser["TRIGGER_LOR"]
    abilitato = sezione.getboolean("Abilita_Controllo_LOR", fallback=False)
    porta_api = sezione.getint("Porta_API_LOR", fallback=8001)

    mappa_nomi_lor = {}
    if "SEQUENZE_LOR" in parser:
        mappa_nomi_lor = {
            chiave: valore.strip()
            for chiave, valore in parser["SEQUENZE_LOR"].items()
            if valore.strip()
        }
    return abilitato, porta_api, mappa_nomi_lor


def carica_catalogo(logger: logging.Logger) -> list[dict]:
    if not FILE_CATALOGO.is_file():
        logger.error(
            "Catalogo canzoni non trovato (%s). Esegui prima CostruisciCatalogo.py. "
            "Il server parte comunque, ma la pagina di voto sara' vuota.",
            FILE_CATALOGO,
        )
        return []
    try:
        with open(FILE_CATALOGO, "r", encoding="utf-8") as f:
            catalogo = json.load(f)
        logger.info("Catalogo caricato: %d canzoni votabili", len(catalogo))
        return catalogo
    except (OSError, json.JSONDecodeError) as errore:
        logger.error("Impossibile leggere il catalogo canzoni: %s", errore)
        return []


def carica_stato_voti_precedente(logger: logging.Logger) -> None:
    """Ripristina i voti dell'ultimo turno se il server e' stato riavviato
    per errore a meta' show, cosi' non si perde nulla per un crash."""
    if not FILE_STATO_VOTI.is_file():
        return
    try:
        with open(FILE_STATO_VOTI, "r", encoding="utf-8") as f:
            dati = json.load(f)
        with _lock_voti:
            voti_correnti.update(dati)
        logger.info("Ripristinati %d voti dal turno precedente", len(voti_correnti))
    except (OSError, json.JSONDecodeError) as errore:
        logger.warning("Impossibile ripristinare lo stato voti precedente: %s", errore)


def salva_stato_voti(logger: logging.Logger) -> None:
    try:
        with _lock_voti:
            istantanea = dict(voti_correnti)
        with open(FILE_STATO_VOTI, "w", encoding="utf-8") as f:
            json.dump(istantanea, f, ensure_ascii=False)
    except OSError as errore:
        logger.warning("Impossibile salvare lo stato dei voti su disco: %s", errore)


# ----------------------------------------------------------------------
# Logica di voto
# ----------------------------------------------------------------------
def calcola_classifica() -> list[dict]:
    """Ritorna il catalogo con conteggio voti e percentuale, ordinato dal
    piu' votato al meno votato."""
    conteggi = {}
    with _lock_voti:
        istantanea_voti = list(voti_correnti.values())
    for id_canzone in istantanea_voti:
        conteggi[id_canzone] = conteggi.get(id_canzone, 0) + 1

    totale_voti = sum(conteggi.values())
    classifica = []
    for canzone in catalogo_canzoni:
        voti = conteggi.get(canzone["id"], 0)
        percentuale = round(100 * voti / totale_voti) if totale_voti else 0
        classifica.append({**canzone, "voti": voti, "percentuale": percentuale})

    classifica.sort(key=lambda voce: voce["voti"], reverse=True)
    return classifica


def _determina_vincitore(classifica: list[dict]):
    """Ritorna la canzone vincente del turno, oppure None se non ci sono
    voti o se c'e' un pareggio in prima posizione: in quel caso nessuno
    vince e la scaletta normale di LOR prosegue senza interferenze."""
    if not classifica or classifica[0]["voti"] == 0:
        return None
    if len(classifica) > 1 and classifica[1]["voti"] == classifica[0]["voti"]:
        return None
    return classifica[0]


# ----------------------------------------------------------------------
# Ponte con LOR (Fase 2): aspetta la fine della canzone in corso, fa
# partire su LOR quella piu' votata, poi azzera i voti per il turno dopo.
# Gira in un thread separato, non blocca mai il server di voto: ogni
# errore di comunicazione con LOR viene solo loggato.
# ----------------------------------------------------------------------
def _chiama_api_lor(metodo: str, percorso: str, porta_api: int):
    url = f"http://127.0.0.1:{porta_api}{percorso}"
    richiesta = urllib.request.Request(url, method=metodo)
    with urllib.request.urlopen(richiesta, timeout=5) as risposta:
        corpo = risposta.read()
    return json.loads(corpo) if corpo else None


def _timespan_a_secondi(valore_timespan: str) -> float:
    try:
        ore, minuti, secondi = valore_timespan.split(":")
        return int(ore) * 3600 + int(minuti) * 60 + float(secondi)
    except (ValueError, AttributeError):
        return 0.0


def _trova_item_id_main_sequence(porta_api: int, nome_sequenza_lor: str) -> str:
    """Cerca in GET /v1/player/mainSequences la voce con questo nome
    esatto (case-insensitive) e ne ritorna l'itemId, da usare con
    playNext. None se non la trova (nome sbagliato in configurazione o
    sequenza non presente nel Main)."""
    risposta = _chiama_api_lor("GET", "/v1/player/mainSequences", porta_api)
    voci = risposta if isinstance(risposta, list) else (risposta or {}).get("value", [])
    for voce in voci:
        if voce.get("name", "").strip().lower() == nome_sequenza_lor.strip().lower():
            return voce.get("itemId")
    return None


def _metti_in_coda_lor(
    logger: logging.Logger, porta_api: int, mappa_nomi_lor: dict, canzone: dict, messaggio_log: str
) -> bool:
    """Cerca la sequenza di 'canzone' in LOR e la manda in coda con
    playNext. Ritorna True se e' andata a buon fine (usato per capire se
    provare la voce successiva della classifica in caso di errore)."""
    nome_lor = mappa_nomi_lor.get(canzone["id"])
    if not nome_lor:
        logger.warning(
            "[LOR] '%s' e' in classifica ma non ha un nome LOR configurato in [SEQUENZE_LOR]",
            canzone["titolo"],
        )
        return False

    item_id = _trova_item_id_main_sequence(porta_api, nome_lor)
    if not item_id:
        logger.warning(
            "[LOR] Sequenza '%s' non trovata in mainSequences: controlla [SEQUENZE_LOR] nell'ini",
            nome_lor,
        )
        return False

    _chiama_api_lor("PUT", f"/v1/player/mainSequences/playNext/{item_id}", porta_api)
    logger.info("[LOR] " + messaggio_log, canzone["titolo"], canzone["voti"])
    return True


def ponte_lor(logger: logging.Logger, porta_api: int, mappa_nomi_lor: dict):
    """Quando la canzone in corso sta per finire, manda in CODA (non
    interrompe nulla) quella piu' richiesta usando
    PUT /v1/player/mainSequences/playNext/{itemId}: la canzone attuale
    finisce naturalmente, poi parte quella vincitrice. mappa_nomi_lor
    associa l'id di ogni canzone del catalogo al nome esatto con cui
    compare in LOR (sezione [SEQUENZE_LOR] dell'ini).

    Se in un turno arrivano nuove richieste con un vincitore chiaro, la
    classifica di quel turno viene salvata (meno il vincitore appena messo
    in coda) come "coda_classifica": se il turno successivo NON riceve
    nessuna nuova richiesta, si prosegue con la prossima voce di quella
    coda invece di lasciar perdere tutto. Appena arrivano richieste nuove
    che determinano un vincitore, la coda salvata viene scartata e
    ricalcolata da zero: le richieste fresche hanno sempre la precedenza.
    Quando la coda si esaurisce (o non c'e' mai stata), la scaletta
    normale di LOR prosegue senza interferenze."""
    global coda_classifica_condivisa, classifica_vincente_condivisa
    logger.info("[LOR] Ponte con LOR avviato (porta API %d)", porta_api)
    id_canzone_lor_precedente = None
    turno_deciso_per = None  # id per cui abbiamo gia' mandato in coda un vincitore
    coda_classifica = []  # voci rimaste dall'ultima classifica con richieste chiare
    classifica_vincente = []  # vincitore + resto, catturata quando decisa
    cronologia_vincitori = deque(maxlen=NUMERO_TURNI_RAFFREDDAMENTO)  # id delle ultime vincitrici: in pausa

    while True:
        try:
            stato = _chiama_api_lor("GET", "/v1/player/status", porta_api)
            coda_riproduzione = (stato or {}).get("playingQueue", {})
            items = coda_riproduzione.get("items", []) if isinstance(coda_riproduzione, dict) else []

            if not items:
                id_canzone_lor_precedente = None
                turno_deciso_per = None
                coda_classifica = []
                classifica_vincente = []
            else:
                item_corrente = items[0]
                id_canzone_lor_corrente = item_corrente.get("id")

                if id_canzone_lor_corrente != id_canzone_lor_precedente:
                    with _lock_voti:
                        voti_correnti.clear()
                    salva_stato_voti(logger)
                    logger.info(
                        "[LOR] Nuova canzone in riproduzione ('%s'): richieste azzerate per il nuovo turno",
                        item_corrente.get("name"),
                    )
                    id_canzone_lor_precedente = id_canzone_lor_corrente
                    turno_deciso_per = None

                secondi_rimanenti = _timespan_a_secondi(item_corrente.get("remainingDuration", ""))

                if secondi_rimanenti <= SOGLIA_FINE_CANZONE_SECONDI and turno_deciso_per != id_canzone_lor_corrente:
                    classifica = calcola_classifica()
                    # Le sequenze vinte negli ultimi NUMERO_TURNI_RAFFREDDAMENTO
                    # turni non possono rivincere subito: da' un po' di varieta'
                    # anche con tanti utenti che votano sempre la stessa cosa.
                    # Restano comunque votabili e conteggiate, solo non possono
                    # vincere finche' non e' passato il raffreddamento.
                    candidati_idonei = [v for v in classifica if v["id"] not in cronologia_vincitori]
                    vincitore = _determina_vincitore(candidati_idonei)
                    turno_deciso_per = id_canzone_lor_corrente

                    if vincitore is not None:
                        # Richieste nuove e chiare in questo turno: la coda
                        # riparte da qui, scartando quella del turno prima -
                        # le richieste fresche hanno sempre la precedenza.
                        coda_classifica = [
                            voce for voce in classifica
                            if voce["voti"] > 0 and voce["id"] != vincitore["id"]
                        ]
                        riuscito = _metti_in_coda_lor(
                            logger, porta_api, mappa_nomi_lor, vincitore,
                            "'%s' messa in coda come prossima sequenza, con %d richieste",
                        )
                        if riuscito:
                            classifica_vincente = [vincitore] + coda_classifica
                            cronologia_vincitori.append(vincitore["id"])
                    elif candidati_idonei and candidati_idonei[0]["voti"] > 0:
                        logger.info("[LOR] Fine turno in pareggio: nessuna sequenza in coda, la scaletta normale di LOR prosegue")
                        coda_classifica = []
                    elif classifica and classifica[0]["voti"] > 0:
                        logger.info(
                            "[LOR] Tutte le richieste di questo turno sono per sequenze in pausa "
                            "(vinte da poco): la scaletta normale di LOR prosegue"
                        )
                        coda_classifica = []
                    else:
                        # Nessuna richiesta nuova in questo turno: se e' rimasta
                        # una coda dal turno con richieste chiare, si prosegue
                        # con la prossima voce non in pausa; altrimenti scaletta
                        # normale.
                        proseguito = False
                        vincitore_da_coda = None
                        while coda_classifica and not proseguito:
                            prossima = coda_classifica.pop(0)
                            if prossima["id"] in cronologia_vincitori:
                                continue
                            proseguito = _metti_in_coda_lor(
                                logger, porta_api, mappa_nomi_lor, prossima,
                                "'%s' messa in coda proseguendo la classifica del turno precedente, con %d richieste",
                            )
                            if proseguito:
                                vincitore_da_coda = prossima
                        if proseguito:
                            classifica_vincente = [vincitore_da_coda] + coda_classifica
                            cronologia_vincitori.append(vincitore_da_coda["id"])
                        else:
                            logger.info("[LOR] Fine turno senza richieste: la scaletta normale di LOR prosegue")

        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as errore:
            logger.warning("[LOR] Impossibile contattare l'API di LOR: %s", errore)
        except Exception as errore:
            logger.error("[LOR] Errore inatteso nel ponte con LOR: %s", errore)

        coda_classifica_condivisa = list(coda_classifica)
        classifica_vincente_condivisa = list(classifica_vincente)
        time.sleep(INTERVALLO_POLLING_LOR_SECONDI)


# ----------------------------------------------------------------------
# Generazione pagine HTML (nessuna dipendenza esterna, solo f-string)
# ----------------------------------------------------------------------
STILE_BASE = """
<style>
  body { font-family: Arial, Helvetica, sans-serif; background:#111; color:#eee;
         margin:0; padding:16px; }
  h1 { font-size:1.4em; text-align:center; }
  .canzone { display:flex; align-items:center; gap:12px; background:#1e1e1e;
             border-radius:10px; padding:10px; margin-bottom:10px; }
  .canzone img { width:64px; height:64px; object-fit:cover; border-radius:6px;
                 background:#333; flex-shrink:0; }
  .canzone .info { flex:1; min-width:0; }
  .canzone .titolo { font-weight:bold; }
  .canzone .artista { color:#aaa; font-size:0.9em; }
  .canzone .durata { color:#888; font-size:0.85em; }
  form.voto button, .reset button { background:#2e7d32; color:#fff; border:none;
             border-radius:6px; padding:10px 14px; font-size:1em; }
  .voce-votata { border:2px solid #2e7d32; }
  .barra { background:#333; border-radius:4px; height:10px; margin-top:6px; overflow:hidden; }
  .barra-interna { background:#2e7d32; height:100%; }
  .percentuale { font-size:0.85em; color:#ccc; }
  .selettore-lingua { text-align:center; margin-bottom:10px; }
  .selettore-lingua a { color:#ccc; text-decoration:none; padding:4px 8px; }
  .selettore-lingua a.attiva { color:#fff; font-weight:bold; text-decoration:underline; }
  .tre-colonne { display:flex; gap:16px; align-items:flex-start; }
  .colonna { flex:1; min-width:0; }
  .colonna h2 { font-size:1.05em; color:#ccc; margin:0 0 8px; }
  .nota-colonna { font-size:0.8em; color:#888; margin:-4px 0 10px; }
  @media (max-width: 900px) {
    .tre-colonne { flex-direction:column; }
  }
</style>
"""


def _selettore_lingua_html(lingua: str, percorso_pagina: str) -> str:
    def classe(codice):
        return "attiva" if codice == lingua else ""
    return f"""
    <div class="selettore-lingua">
      <a class="{classe('it')}" href="/lingua?imposta=it&torna={percorso_pagina}">IT</a> |
      <a class="{classe('en')}" href="/lingua?imposta=en&torna={percorso_pagina}">EN</a>
    </div>
    """


def pagina_voto(id_elettore: str, lingua: str = LINGUA_DEFAULT) -> str:
    with _lock_voti:
        voto_attuale = voti_correnti.get(id_elettore)
    righe = []
    if not catalogo_canzoni:
        righe.append(f"<p>{testo(lingua, 'nessuna_canzone')}</p>")
    for canzone in catalogo_canzoni:
        selezionata = canzone["id"] == voto_attuale
        classe_extra = " voce-votata" if selezionata else ""
        immagine_html = (
            f'<img src="/copertine/{html.escape(canzone["copertina"])}" alt="">'
            if canzone.get("copertina")
            else '<img src="" alt="" style="visibility:hidden">'
        )
        etichetta_bottone = testo(lingua, "bottone_votato") if selezionata else testo(lingua, "bottone_vota")
        titolo_escaped = html.escape(canzone['titolo'])
        artista_escaped = html.escape(canzone['artista']) or "&nbsp;"
        durata_escaped = html.escape(canzone['durata_testo'])
        id_escaped = html.escape(canzone['id'])
        righe.append(f"""
        <div class="canzone{classe_extra}">
          {immagine_html}
          <div class="info">
            <div class="titolo">{titolo_escaped}</div>
            <div class="artista">{artista_escaped}</div>
            <div class="durata">{durata_escaped}</div>
          </div>
          <form class="voto" method="post" action="/vota">
            <input type="hidden" name="id" value="{id_escaped}">
            <button type="submit">{etichetta_bottone}</button>
          </form>
        </div>
        """)

    return f"""<!DOCTYPE html>
<html lang="{lingua}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{testo(lingua, 'titolo_pagina_voto')}</title>
{STILE_BASE}
</head><body>
{_selettore_lingua_html(lingua, '/')}
<h1>{testo(lingua, 'intestazione_voto')}</h1>
<p style="text-align:center;color:#999">{testo(lingua, 'istruzioni_voto')}</p>
{''.join(righe)}
</body></html>"""


def _righe_canzoni_html(voci: list, lingua: str, con_barra: bool) -> str:
    righe = []
    for voce in voci:
        titolo_escaped = html.escape(voce['titolo'])
        artista_escaped = html.escape(voce['artista']) or "&nbsp;"
        barra_html = (
            f"""<div class="barra"><div class="barra-interna" style="width:{voce['percentuale']}%"></div></div>
            <div class="percentuale">{voce['percentuale']}%</div>"""
            if con_barra else ""
        )
        righe.append(f"""
        <div class="canzone">
          <div class="info">
            <div class="titolo">{titolo_escaped} - {voce['voti']} {testo(lingua, 'voti_suffisso')}</div>
            <div class="artista">{artista_escaped}</div>
            {barra_html}
          </div>
        </div>
        """)
    return ''.join(righe)


def pagina_risultati(lingua: str = LINGUA_DEFAULT) -> str:
    classifica = calcola_classifica()
    totale_voti = sum(v["voti"] for v in classifica)
    classifica_votate = [v for v in classifica if v["voti"] > 0]
    corpo_live = _righe_canzoni_html(classifica_votate, lingua, con_barra=True) or f"<p>{testo(lingua, 'nessun_voto')}</p>"

    vincente = classifica_vincente_condivisa
    corpo_vincente = _righe_canzoni_html(vincente, lingua, con_barra=False) if vincente else f"<p>{testo(lingua, 'nessuna_vincente')}</p>"

    coda = coda_classifica_condivisa
    corpo_coda = _righe_canzoni_html(coda, lingua, con_barra=False) if coda else f"<p>{testo(lingua, 'coda_vuota')}</p>"

    return f"""<!DOCTYPE html>
<html lang="{lingua}"><head><meta charset="utf-8">
<meta http-equiv="refresh" content="2">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{testo(lingua, 'titolo_pagina_risultati')}</title>
{STILE_BASE}
</head><body>
{_selettore_lingua_html(lingua, '/risultati')}
<h1>{testo(lingua, 'intestazione_risultati')} - {totale_voti} {testo(lingua, 'voti_totali')}</h1>
<div class="tre-colonne">
  <div class="colonna">
    <h2>{testo(lingua, 'colonna_classifica_live')}</h2>
    {corpo_live}
  </div>
  <div class="colonna">
    <h2>{testo(lingua, 'colonna_vincente')}</h2>
    <p class="nota-colonna">{testo(lingua, 'colonna_vincente_nota')}</p>
    {corpo_vincente}
  </div>
  <div class="colonna">
    <h2>{testo(lingua, 'colonna_coda_salvata')}</h2>
    <p class="nota-colonna">{testo(lingua, 'colonna_coda_salvata_nota')}</p>
    {corpo_coda}
  </div>
</div>
<form class="reset" method="post" action="/reset" onsubmit="return confirm('{testo(lingua, 'conferma_reset')}');">
  <button type="submit">{testo(lingua, 'bottone_reset')}</button>
</form>
</body></html>"""


def pagina_login(lingua: str = LINGUA_DEFAULT, errore: bool = False) -> str:
    messaggio_errore = f'<p style="color:#e57373">{testo(lingua, "pagina_login_errore")}</p>' if errore else ""
    return f"""<!DOCTYPE html>
<html lang="{lingua}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{testo(lingua, 'pagina_login_titolo')}</title>
{STILE_BASE}
</head><body>
<h1>{testo(lingua, 'pagina_login_titolo')}</h1>
<p style="text-align:center;color:#999">{testo(lingua, 'pagina_login_istruzioni')}</p>
{messaggio_errore}
<form method="post" action="/accedi" style="max-width:280px;margin:0 auto;text-align:center">
  <input type="password" name="token" autofocus style="width:100%;padding:10px;margin-bottom:10px;box-sizing:border-box">
  <button type="submit">{testo(lingua, 'pagina_login_bottone')}</button>
</form>
</body></html>"""


# ----------------------------------------------------------------------
# Server HTTP
# ----------------------------------------------------------------------
class GestoreRichieste(BaseHTTPRequestHandler):
    logger: logging.Logger = None  # impostato in avvia_server()
    token_admin: str = ""  # impostato in avvia_server(); vuoto = nessuna protezione
    timeout = TIMEOUT_SOCKET_SECONDI  # chiude chi apre una connessione e non manda dati

    def log_message(self, formato, *args):
        pass  # evitiamo il log di default sulla console, usiamo self.logger

    def _leggi_cookie(self, nome: str) -> str:
        intestazione_cookie = self.headers.get("Cookie")
        if intestazione_cookie:
            jar = cookies.SimpleCookie()
            jar.load(intestazione_cookie)
            if nome in jar:
                return jar[nome].value
        return ""

    def _leggi_o_crea_id_elettore(self) -> str:
        return self._leggi_cookie(NOME_COOKIE_ELETTORE) or uuid.uuid4().hex

    def _leggi_lingua(self) -> str:
        lingua = self._leggi_cookie(NOME_COOKIE_LINGUA)
        return lingua if lingua in LINGUE_VALIDE else LINGUA_DEFAULT

    def _autenticato(self) -> bool:
        if not self.token_admin:
            return True  # protezione disattivata (token vuoto in configurazione)
        return self._leggi_cookie(NOME_COOKIE_ADMIN) == self.token_admin

    def _invia_html(self, corpo: str, id_elettore: str = None, codice: int = 200):
        dati = corpo.encode("utf-8")
        self.send_response(codice)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(dati)))
        if id_elettore:
            self.send_header(
                "Set-Cookie", f"{NOME_COOKIE_ELETTORE}={id_elettore}; Path=/; Max-Age=2592000"
            )
        self.end_headers()
        self.wfile.write(dati)

    def _invia_redirect(self, percorso: str, id_elettore: str = None, lingua: str = None, token_admin: str = None):
        self.send_response(303)
        self.send_header("Location", percorso)
        if id_elettore:
            self.send_header(
                "Set-Cookie", f"{NOME_COOKIE_ELETTORE}={id_elettore}; Path=/; Max-Age=2592000"
            )
        if lingua:
            self.send_header(
                "Set-Cookie", f"{NOME_COOKIE_LINGUA}={lingua}; Path=/; Max-Age=2592000"
            )
        if token_admin:
            self.send_header(
                "Set-Cookie", f"{NOME_COOKIE_ADMIN}={token_admin}; Path=/; Max-Age=43200"
            )
        self.end_headers()

    def _servi_copertina(self, percorso: str):
        nome_file = percorso.removeprefix("/copertine/")
        file_immagine = (CARTELLA_COPERTINE / nome_file).resolve()

        if CARTELLA_COPERTINE not in file_immagine.parents or not file_immagine.is_file():
            self.send_response(404)
            self.end_headers()
            return

        estensione = file_immagine.suffix.lower()
        content_type = "image/png" if estensione == ".png" else "image/jpeg"
        dati = file_immagine.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(dati)))
        self.send_header("Cache-Control", "max-age=3600")
        self.end_headers()
        self.wfile.write(dati)

    def _richiesta_troppo_frequente(self) -> bool:
        """True se questo IP ha gia' fatto una richiesta POST negli ultimi
        INTERVALLO_MINIMO_RICHIESTA_SECONDI secondi (anti-spam/flood)."""
        ip_client = self.client_address[0]
        ora = time.monotonic()
        with _lock_rate_limit:
            ultima = _ultima_richiesta_per_ip.get(ip_client)
            if ultima is not None and ora - ultima < INTERVALLO_MINIMO_RICHIESTA_SECONDI:
                return True
            _ultima_richiesta_per_ip[ip_client] = ora
            return False

    def _gestisci_cambio_lingua(self, query: dict):
        lingua_scelta = query.get("imposta", [LINGUA_DEFAULT])[0]
        if lingua_scelta not in LINGUE_VALIDE:
            lingua_scelta = LINGUA_DEFAULT

        percorso_ritorno = query.get("torna", ["/"])[0]
        if not percorso_ritorno.startswith("/"):
            percorso_ritorno = "/"  # mai reindirizzare fuori dal nostro sito

        self._invia_redirect(percorso_ritorno, lingua=lingua_scelta)

    def do_GET(self):
        try:
            parti_url = urlsplit(self.path)
            percorso = parti_url.path
            query = parse_qs(parti_url.query)

            if percorso == "/" or percorso == "":
                id_elettore = self._leggi_o_crea_id_elettore()
                lingua = self._leggi_lingua()
                self._invia_html(pagina_voto(id_elettore, lingua), id_elettore=id_elettore)
            elif percorso == "/risultati":
                token_query = query.get("token", [None])[0]
                if token_query and self.token_admin and token_query == self.token_admin:
                    # arrivo da un link/pulsante con la password gia' nell'url
                    # (es. il pulsante nella GUI): autentica e ripulisce l'url
                    self._invia_redirect("/risultati", token_admin=self.token_admin)
                elif self._autenticato():
                    self._invia_html(pagina_risultati(self._leggi_lingua()))
                else:
                    self._invia_html(pagina_login(self._leggi_lingua()), codice=401)
            elif percorso == "/lingua":
                self._gestisci_cambio_lingua(query)
            elif percorso.startswith("/copertine/"):
                self._servi_copertina(percorso)
            else:
                self.send_response(404)
                self.end_headers()
        except Exception as errore:
            self.logger.error("Errore gestendo GET %s: %s", self.path, errore)
            self.send_response(500)
            self.end_headers()

    def do_POST(self):
        if self._richiesta_troppo_frequente():
            self.send_response(429)
            self.send_header("Retry-After", "2")
            self.end_headers()
            return
        try:
            try:
                lunghezza = int(self.headers.get("Content-Length", 0))
            except (TypeError, ValueError):
                lunghezza = 0  # header Content-Length corrotto/assente: corpo vuoto invece di crashare

            if lunghezza > MAX_LUNGHEZZA_CORPO_POST:
                # corpo anomalo per una pagina che manda solo un id o una password
                # corti: rifiutiamo senza leggerlo (evita di restare bloccati a
                # ricevere un payload enorme) e chiudiamo la connessione.
                self.logger.warning(
                    "POST %s rifiutato: corpo troppo grande (%d byte)", self.path, lunghezza
                )
                self.send_response(413)
                self.end_headers()
                self.close_connection = True
                return

            corpo_grezzo = self.rfile.read(lunghezza) if lunghezza else b""
            corpo = corpo_grezzo.decode("utf-8", errors="replace")
            campi = parse_qs(corpo)

            if self.path == "/vota":
                id_elettore = self._leggi_o_crea_id_elettore()
                id_canzone = _sanifica_testo_pubblico(campi.get("id", [""])[0])
                id_validi = {c["id"] for c in catalogo_canzoni}
                if id_canzone in id_validi:
                    with _lock_voti:
                        voti_correnti[id_elettore] = id_canzone
                    salva_stato_voti(self.logger)
                    self.logger.info("Voto registrato: elettore=%s canzone=%s", id_elettore, id_canzone)
                else:
                    self.logger.warning("Voto ignorato, id canzone non valido: '%s'", id_canzone)
                self._invia_redirect("/", id_elettore=id_elettore)

            elif self.path == "/reset":
                if not self._autenticato():
                    self.send_response(403)
                    self.end_headers()
                    return
                with _lock_voti:
                    voti_correnti.clear()
                salva_stato_voti(self.logger)
                self.logger.info("Voti azzerati: nuovo turno iniziato")
                self._invia_redirect("/risultati")

            elif self.path == "/accedi":
                token_inserito = campi.get("token", [""])[0]
                if self.token_admin and token_inserito == self.token_admin:
                    self.logger.info("Accesso amministratore riuscito")
                    self._invia_redirect("/risultati", token_admin=self.token_admin)
                else:
                    self.logger.warning("Tentativo di accesso amministratore con password errata")
                    self._invia_html(pagina_login(self._leggi_lingua(), errore=True), codice=401)

            else:
                self.send_response(404)
                self.end_headers()
        except Exception as errore:
            self.logger.error("Errore gestendo POST %s: %s", self.path, errore)
            self.send_response(500)
            self.end_headers()


class ServerVoto(ThreadingHTTPServer):
    """ThreadingHTTPServer con un tetto al numero di connessioni gestite in
    contemporanea. Ogni connessione fa partire un thread: senza un limite,
    un flood di connessioni (anche senza mandare dati validi, quindi prima
    che scatti il rate limiting per IP) potrebbe consumare memoria/CPU del
    PC dello show - lo stesso PC che deve restare libero per pilotare le
    luci. Oltre il tetto, le connessioni in piu' vengono chiuse subito
    senza aprire un thread."""
    daemon_threads = True
    logger: logging.Logger = None  # impostato in avvia_server()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._semaforo_connessioni = threading.BoundedSemaphore(MAX_CONNESSIONI_CONTEMPORANEE)

    def process_request(self, request, client_address):
        if not self._semaforo_connessioni.acquire(blocking=False):
            if self.logger:
                self.logger.warning(
                    "Troppe connessioni in contemporanea (>%d): connessione da %s rifiutata subito",
                    MAX_CONNESSIONI_CONTEMPORANEE, client_address[0],
                )
            self.shutdown_request(request)
            return
        super().process_request(request, client_address)

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._semaforo_connessioni.release()


def avvia_server():
    logger = configura_logging()
    logger.info("=== Avvio VotoShow ===")

    global catalogo_canzoni
    catalogo_canzoni = carica_catalogo(logger)
    carica_stato_voti_precedente(logger)

    porta = leggi_porta_server(logger)
    GestoreRichieste.logger = logger

    token_admin = leggi_token_admin(logger)
    GestoreRichieste.token_admin = token_admin
    if token_admin:
        logger.info("Protezione /risultati e /reset attiva (password configurata)")
    else:
        logger.warning("Protezione /risultati e /reset DISATTIVATA (Token_Amministratore vuoto nell'ini)")

    abilitato_lor, porta_api_lor, mappa_nomi_lor = leggi_configurazione_lor(logger)
    if abilitato_lor:
        threading.Thread(
            target=ponte_lor, args=(logger, porta_api_lor, mappa_nomi_lor), daemon=True
        ).start()
    else:
        logger.info("[LOR] Integrazione con LOR disabilitata (Abilita_Controllo_LOR = False)")

    server = ServerVoto(("0.0.0.0", porta), GestoreRichieste)
    server.logger = logger
    logger.info("Server di voto in ascolto su http://0.0.0.0:%d (pagina ospiti: /, risultati: /risultati)", porta)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Interruzione richiesta dall'utente")
    finally:
        server.server_close()
        logger.info("=== VotoShow terminato ===")


if __name__ == "__main__":
    avvia_server()
