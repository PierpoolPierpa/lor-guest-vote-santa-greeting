"""
schede_luci_db.py

Livello database (SQLite) per il catalogo delle schede di controllo luci dello
show natalizio - ex foglio Excel "SCHEDE E CANALI E FIGURE 2025.xltx".

Tabelle:
- scheda: 1 riga per scheda (LOR o UNI/Pixcon16), dati di intestazione
- canale: 1:N, un canale per riga (posizione, figura illuminata, connettori)
- alimentazione: 1:1 con la scheda, blocco volt/ampere/alimentatori/watt
- nota_scheda: 1:N, note libere legate alla scheda (non a un canale preciso)
- memo_generale: elenco indipendente di promemoria "da ricordarsi ogni anno"

Alcune colonne "conteggio" (CanaliTot, QtaSpine, NumeroAlimentatori, BulbiPerCanale,
CanaliXBank, BankXScheda) sono TEXT e non INTEGER: nel foglio Excel originale almeno
una scheda (CMB24, ID #11/#12) ha un valore non numerico in quella colonna
(es. "8 X 3 RGB"), quindi tenerle come testo libero evita di perdere dati reali.
"""

import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "schede_luci.db"


def connetti() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def inizializza_database() -> None:
    with connetti() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS scheda (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT NOT NULL,
                identificativo TEXT NOT NULL,
                mac TEXT,
                modello TEXT,
                firmware TEXT,
                protocollo TEXT,
                porta TEXT,
                modalita_rete TEXT,
                velocita_kbps TEXT,
                porte_lor TEXT,
                enhanced TEXT,
                colore_cavo_rete TEXT,
                colore_etichetta_cavi TEXT,
                facciata TEXT,
                tipo_spinotto_out_scheda TEXT,
                tipo_spinotto_in_raddrizzatori TEXT,
                tipo_spinotto_out_raddrizzatori TEXT,
                ordine_pagina INTEGER
            );

            CREATE TABLE IF NOT EXISTS canale (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scheda_id INTEGER NOT NULL,
                posizione INTEGER,
                etichetta_prefisso TEXT,
                numero_canale INTEGER,
                figura TEXT,
                tipo_spinotti_catena TEXT,
                tipo_spinotti_prolunga TEXT,
                guaina_etichetta_prolunga TEXT,
                guaina_etichetta_scheda TEXT,
                poli_dc TEXT,
                tipo_spinotto_out_catena TEXT,
                tipo_spinotto_in_out_prolunga TEXT,
                note TEXT,
                FOREIGN KEY (scheda_id) REFERENCES scheda(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS alimentazione (
                scheda_id INTEGER PRIMARY KEY,
                alimentazione TEXT,
                canali_tot TEXT,
                ampere_max_canale TEXT,
                ampere_max_bank TEXT,
                tipo_spina TEXT,
                qta_spine TEXT,
                ampere TEXT,
                altezza REAL,
                larghezza REAL,
                numero_alimentatori TEXT,
                alimentatore_1_watt_amp TEXT,
                alimentatore_2_watt_amp TEXT,
                bulbi_per_canale TEXT,
                watt_x_bulbo REAL,
                watt_x_canale REAL,
                canali_x_bank TEXT,
                watt_x_bank REAL,
                bank_x_scheda TEXT,
                tot_watt_x_scheda REAL,
                tot_watt TEXT,
                tot_ampere TEXT,
                FOREIGN KEY (scheda_id) REFERENCES scheda(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS nota_scheda (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scheda_id INTEGER NOT NULL,
                testo TEXT NOT NULL,
                FOREIGN KEY (scheda_id) REFERENCES scheda(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS memo_generale (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                testo TEXT NOT NULL,
                ordine INTEGER
            );
            """
        )
        # Migrazione additiva (2026-07-24, richiesta esplicita utente: campo MAC sotto
        # Identificativo) - CREATE TABLE IF NOT EXISTS non tocca una tabella scheda gia'
        # esistente da prima di questo campo, serve ALTER TABLE solo se la colonna manca.
        colonne = {riga["name"] for riga in conn.execute("PRAGMA table_info(scheda)")}
        if "mac" not in colonne:
            conn.execute("ALTER TABLE scheda ADD COLUMN mac TEXT")


# --- Scheda ---

def get_schede() -> list[sqlite3.Row]:
    with connetti() as conn:
        return conn.execute("SELECT * FROM scheda ORDER BY ordine_pagina, id").fetchall()


def get_scheda(scheda_id: int) -> sqlite3.Row | None:
    with connetti() as conn:
        return conn.execute("SELECT * FROM scheda WHERE id = ?", (scheda_id,)).fetchone()


def add_scheda(**campi) -> int:
    colonne = list(campi.keys())
    segnaposto = ", ".join("?" for _ in colonne)
    with connetti() as conn:
        cur = conn.execute(
            f"INSERT INTO scheda ({', '.join(colonne)}) VALUES ({segnaposto})",
            [campi[c] for c in colonne],
        )
        return cur.lastrowid


def update_scheda(scheda_id: int, **campi) -> None:
    colonne = list(campi.keys())
    set_clause = ", ".join(f"{c} = ?" for c in colonne)
    with connetti() as conn:
        conn.execute(
            f"UPDATE scheda SET {set_clause} WHERE id = ?",
            [campi[c] for c in colonne] + [scheda_id],
        )


def delete_scheda(scheda_id: int) -> None:
    """ON DELETE CASCADE si occupa di canale/alimentazione/nota_scheda."""
    with connetti() as conn:
        conn.execute("DELETE FROM scheda WHERE id = ?", (scheda_id,))


# --- Canali 1:N ---

def get_canali(scheda_id: int) -> list[sqlite3.Row]:
    with connetti() as conn:
        return conn.execute(
            "SELECT * FROM canale WHERE scheda_id = ? ORDER BY posizione, id", (scheda_id,)
        ).fetchall()


def set_canali(scheda_id: int, canali: list[dict]) -> None:
    """Sostituzione completa (delete+insert) - il chiamante passa sempre l'elenco intero."""
    colonne = [
        "posizione", "etichetta_prefisso", "numero_canale", "figura",
        "tipo_spinotti_catena", "tipo_spinotti_prolunga", "guaina_etichetta_prolunga",
        "guaina_etichetta_scheda", "poli_dc", "tipo_spinotto_out_catena",
        "tipo_spinotto_in_out_prolunga", "note",
    ]
    with connetti() as conn:
        conn.execute("DELETE FROM canale WHERE scheda_id = ?", (scheda_id,))
        for canale in canali:
            valori = [canale.get(c) for c in colonne]
            conn.execute(
                f"INSERT INTO canale (scheda_id, {', '.join(colonne)}) "
                f"VALUES (?, {', '.join('?' for _ in colonne)})",
                [scheda_id] + valori,
            )


# --- Alimentazione 1:1 ---

def get_alimentazione(scheda_id: int) -> sqlite3.Row | None:
    with connetti() as conn:
        return conn.execute(
            "SELECT * FROM alimentazione WHERE scheda_id = ?", (scheda_id,)
        ).fetchone()


def set_alimentazione(scheda_id: int, **campi) -> None:
    colonne = list(campi.keys())
    segnaposto = ", ".join("?" for _ in colonne)
    aggiornamento = ", ".join(f"{c} = excluded.{c}" for c in colonne)
    with connetti() as conn:
        conn.execute(
            f"INSERT INTO alimentazione (scheda_id, {', '.join(colonne)}) "
            f"VALUES (?, {segnaposto}) "
            f"ON CONFLICT(scheda_id) DO UPDATE SET {aggiornamento}",
            [scheda_id] + [campi[c] for c in colonne],
        )


# --- Note libere per scheda 1:N ---

def get_note_scheda(scheda_id: int) -> list[sqlite3.Row]:
    with connetti() as conn:
        return conn.execute(
            "SELECT * FROM nota_scheda WHERE scheda_id = ? ORDER BY id", (scheda_id,)
        ).fetchall()


def set_note_scheda(scheda_id: int, note: list[str]) -> None:
    with connetti() as conn:
        conn.execute("DELETE FROM nota_scheda WHERE scheda_id = ?", (scheda_id,))
        for testo in note:
            testo = (testo or "").strip()
            if testo:
                conn.execute(
                    "INSERT INTO nota_scheda (scheda_id, testo) VALUES (?, ?)", (scheda_id, testo)
                )


# --- Memo generale (svincolato da qualunque scheda) ---

def get_memo_generale() -> list[sqlite3.Row]:
    with connetti() as conn:
        return conn.execute("SELECT * FROM memo_generale ORDER BY ordine, id").fetchall()


def set_memo_generale(memo: list[str]) -> None:
    with connetti() as conn:
        conn.execute("DELETE FROM memo_generale")
        for indice, testo in enumerate(memo):
            testo = (testo or "").strip()
            if testo:
                conn.execute(
                    "INSERT INTO memo_generale (testo, ordine) VALUES (?, ?)", (testo, indice)
                )


inizializza_database()
