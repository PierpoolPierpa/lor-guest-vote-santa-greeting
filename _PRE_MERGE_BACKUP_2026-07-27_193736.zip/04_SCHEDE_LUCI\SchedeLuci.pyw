"""
SchedeLuci.pyw

GUI standalone per consultare/modificare i dati tecnici delle schede di
controllo luci dello show natalizio (ex foglio Excel
"SCHEDE E CANALI E FIGURE 2025.xltx"): schede LOR/UNI, canali, alimentazione,
note libere e un elenco di memo generali "da ricordarsi ogni anno".

Vive fuori da V1965 di proposito (richiesta esplicita utente 2026-07-24): fa
parte del progetto show (E:\\04_SHOW\\2026\\), non del gestionale PC. Lanciabile
anche da ManagerShow.pyw con un bottone dedicato.

Nessuna dipendenza esterna: solo tkinter/ttk + sqlite3, stessa libreria
standard gia' usata in ManagerShow.pyw.
"""

import tkinter as tk
from tkinter import messagebox, ttk

import schede_luci_db as db

TIPI_SCHEDA = ("LOR", "UNI")


class FinestraElenco(tk.Toplevel):
    """Dialog generico per un elenco di righe (colonne+campi parametrizzati) -
    riusato per Canali, Note libere e Memo Generale, stesso principio del
    companion generico gia' usato per Inventario Device Casa in V1965."""

    def __init__(self, padre, titolo: str, colonne: list[tuple], campi: list[tuple], elementi: list[dict]):
        """
        colonne: [(chiave, titolo, larghezza), ...] mostrate nella Treeview
        campi: [(chiave, etichetta), ...] editati nel mini-dialog riga (puo'
               includere chiavi non mostrate come colonna, per non perdere dati)
        elementi: lista di dict iniziali
        """
        super().__init__(padre)
        self.title(titolo)
        self.colonne = colonne
        self.campi = campi
        self.elementi = [dict(e) for e in elementi]
        self.risultato = None
        self.transient(padre)
        self.grab_set()

        chiavi_colonne = [c[0] for c in colonne]
        self.albero = ttk.Treeview(self, columns=chiavi_colonne, show="headings", selectmode="browse")
        for chiave, titolo_colonna, larghezza in colonne:
            self.albero.heading(chiave, text=titolo_colonna)
            self.albero.column(chiave, width=larghezza, anchor="w")
        self.albero.pack(fill="both", expand=True, padx=8, pady=8)
        self.albero.bind("<Double-1>", lambda evento: self._modifica())

        frame_bottoni = ttk.Frame(self)
        frame_bottoni.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(frame_bottoni, text="AGGIUNGI", command=self._aggiungi).pack(side="left")
        ttk.Button(frame_bottoni, text="MODIFICA", command=self._modifica).pack(side="left", padx=4)
        ttk.Button(frame_bottoni, text="RIMUOVI", command=self._rimuovi).pack(side="left")

        frame_salva = ttk.Frame(self)
        frame_salva.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(frame_salva, text="ANNULLA", command=self.destroy).pack(side="right")
        ttk.Button(frame_salva, text="SALVA E CHIUDI", command=self._salva_e_chiudi).pack(side="right", padx=4)

        self._aggiorna_griglia()
        larghezza_totale = max(420, sum(c[2] for c in colonne) + 40)
        self.geometry(f"{larghezza_totale}x360")

    def _aggiorna_griglia(self):
        self.albero.delete(*self.albero.get_children())
        for indice, elemento in enumerate(self.elementi):
            valori = [elemento.get(c[0], "") for c in self.colonne]
            self.albero.insert("", "end", iid=str(indice), values=valori)

    def _indice_selezionato(self):
        selezione = self.albero.selection()
        if not selezione:
            return None
        return int(selezione[0])

    def _aggiungi(self):
        risultato = FinestraRigaElenco(self, "NUOVA RIGA - " + self.title(), self.campi, {}).mostra()
        if risultato is not None:
            self.elementi.append(risultato)
            self._aggiorna_griglia()

    def _modifica(self):
        indice = self._indice_selezionato()
        if indice is None:
            return
        risultato = FinestraRigaElenco(self, "MODIFICA RIGA - " + self.title(), self.campi, self.elementi[indice]).mostra()
        if risultato is not None:
            self.elementi[indice] = risultato
            self._aggiorna_griglia()

    def _rimuovi(self):
        indice = self._indice_selezionato()
        if indice is None:
            return
        del self.elementi[indice]
        self._aggiorna_griglia()

    def _salva_e_chiudi(self):
        self.risultato = self.elementi
        self.destroy()

    def mostra(self):
        self.wait_window()
        return self.risultato


class FinestraRigaElenco(tk.Toplevel):
    """Mini-dialog per aggiungere/modificare una riga di FinestraElenco."""

    def __init__(self, padre, titolo: str, campi: list[tuple], riga_esistente: dict):
        super().__init__(padre)
        self.title(titolo)
        self.campi = campi
        self.risultato = None
        self.transient(padre)
        self.grab_set()

        self.variabili = {}
        for indice, (chiave, etichetta) in enumerate(campi):
            ttk.Label(self, text=etichetta).grid(row=indice, column=0, sticky="w", padx=8, pady=4)
            variabile = tk.StringVar(value=str(riga_esistente.get(chiave, "") or ""))
            ttk.Entry(self, textvariable=variabile, width=40).grid(row=indice, column=1, padx=8, pady=4)
            self.variabili[chiave] = variabile

        frame_bottoni = ttk.Frame(self)
        frame_bottoni.grid(row=len(campi), column=0, columnspan=2, pady=8)
        ttk.Button(frame_bottoni, text="ANNULLA", command=self.destroy).pack(side="left", padx=4)
        ttk.Button(frame_bottoni, text="SALVA", command=self._salva).pack(side="left")

    def _salva(self):
        self.risultato = {chiave: variabile.get().strip() for chiave, variabile in self.variabili.items()}
        self.destroy()

    def mostra(self):
        self.wait_window()
        return self.risultato


CAMPI_HEADER = [
    ("tipo", "Tipo scheda (LOR/UNI)"),
    ("identificativo", "Identificativo (ID # oppure indirizzo IP)"),
    ("mac", "Indirizzo MAC"),
    ("modello", "Modello scheda"),
    ("firmware", "Firmware"),
    ("protocollo", "Protocollo (solo UNI)"),
    ("porta", "Porta (solo UNI)"),
    ("modalita_rete", "Modalita' rete (es. MULTICAST, solo UNI)"),
    ("velocita_kbps", "Velocita'"),
    ("porte_lor", "Porte LOR (solo LOR)"),
    ("enhanced", "Enhanced (solo LOR)"),
    ("colore_cavo_rete", "Colore cavo rete"),
    ("colore_etichetta_cavi", "Colore etichetta cavi"),
    ("facciata", "Facciata / lato"),
    ("tipo_spinotto_out_scheda", "Tipo spinotto OUT scheda"),
    ("tipo_spinotto_in_raddrizzatori", "Tipo spinotto IN raddrizzatori (solo LOR)"),
    ("tipo_spinotto_out_raddrizzatori", "Tipo spinotto OUT raddrizzatori (solo LOR)"),
]

CAMPI_ALIMENTAZIONE = [
    ("alimentazione", "Alimentazione (es. 220 VOLTS / 12 VDC)"),
    ("canali_tot", "Canali totali"),
    ("ampere_max_canale", "Ampere max per canale"),
    ("ampere_max_bank", "Ampere max per bank"),
    ("tipo_spina", "Tipo spina"),
    ("qta_spine", "Quantita' spine"),
    ("ampere", "Ampere"),
    ("altezza", "Altezza cassa (mm)"),
    ("larghezza", "Larghezza cassa (mm)"),
    ("numero_alimentatori", "Numero alimentatori (solo UNI)"),
    ("alimentatore_1_watt_amp", "1° alimentatore Watt/Amp"),
    ("alimentatore_2_watt_amp", "2° alimentatore Watt/Amp"),
    ("bulbi_per_canale", "Bulbi per canale (solo UNI)"),
    ("watt_x_bulbo", "Watt per bulbo"),
    ("watt_x_canale", "Watt per canale"),
    ("canali_x_bank", "Canali per bank"),
    ("watt_x_bank", "Watt per bank"),
    ("bank_x_scheda", "Bank per scheda"),
    ("tot_watt_x_scheda", "Totale Watt per scheda"),
    ("tot_watt", "Totale Watt"),
    ("tot_ampere", "Totale Ampere"),
]

COLONNE_CANALI = [
    ("posizione", "Pos.", 45),
    ("etichetta_prefisso", "Prefisso", 60),
    ("numero_canale", "N.", 40),
    ("figura", "Figura", 180),
    ("tipo_spinotti_catena", "Sp. catena", 90),
    ("tipo_spinotti_prolunga", "Sp. prolunga", 90),
    ("poli_dc", "Poli DC", 90),
    ("note", "Note", 220),
]

CAMPI_CANALE = [
    ("posizione", "Posizione su scheda"),
    ("etichetta_prefisso", "Prefisso etichetta (CH/UNI)"),
    ("numero_canale", "Numero canale"),
    ("figura", "Figura illuminata"),
    ("tipo_spinotti_catena", "Tipo spinotti su catena LED"),
    ("tipo_spinotti_prolunga", "Tipo spinotti su prolunga"),
    ("guaina_etichetta_prolunga", "Guaina etichetta su prolunga"),
    ("guaina_etichetta_scheda", "Guaina etichetta su scheda"),
    ("poli_dc", "Poli DC / maschio-femmina"),
    ("tipo_spinotto_out_catena", "Tipo spinotto OUT catena LED"),
    ("tipo_spinotto_in_out_prolunga", "Tipo spinotto IN/OUT prolunga"),
    ("note", "Note del canale"),
]


class FinestraDettaglioScheda(tk.Toplevel):
    def __init__(self, padre, scheda_id: int | None):
        super().__init__(padre)
        self.scheda_id = scheda_id
        self.is_new = scheda_id is None
        self.salvato = False
        self.transient(padre)
        self.grab_set()

        scheda = dict(db.get_scheda(scheda_id)) if not self.is_new else {}
        alimentazione = dict(db.get_alimentazione(scheda_id) or {}) if not self.is_new else {}
        self.canali = [dict(c) for c in db.get_canali(scheda_id)] if not self.is_new else []
        self.note = [dict(n) for n in db.get_note_scheda(scheda_id)] if not self.is_new else []

        self.title("NUOVA SCHEDA - Luci di Natale" if self.is_new else f"SCHEDA {scheda.get('identificativo', '')} - Luci di Natale")
        self.geometry("460x600")

        canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        frame_scroll = ttk.Frame(canvas)
        frame_scroll.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame_scroll, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y", pady=8)
        canvas.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)

        self.variabili = {}
        riga = 0
        ttk.Label(frame_scroll, text="INTESTAZIONE SCHEDA", font=("Segoe UI", 9, "bold")).grid(row=riga, column=0, columnspan=2, sticky="w", pady=(0, 6))
        riga += 1
        for chiave, etichetta in CAMPI_HEADER:
            ttk.Label(frame_scroll, text=etichetta, wraplength=200).grid(row=riga, column=0, sticky="w", pady=2)
            variabile = tk.StringVar(value=str(scheda.get(chiave, "") or ""))
            if chiave == "tipo":
                combo = ttk.Combobox(frame_scroll, textvariable=variabile, values=TIPI_SCHEDA, state="readonly", width=27)
                combo.grid(row=riga, column=1, pady=2)
                if not variabile.get():
                    variabile.set(TIPI_SCHEDA[0])
            else:
                ttk.Entry(frame_scroll, textvariable=variabile, width=30).grid(row=riga, column=1, pady=2)
            self.variabili[chiave] = variabile
            riga += 1

        ttk.Label(frame_scroll, text="ALIMENTAZIONE", font=("Segoe UI", 9, "bold")).grid(row=riga, column=0, columnspan=2, sticky="w", pady=(10, 6))
        riga += 1
        for chiave, etichetta in CAMPI_ALIMENTAZIONE:
            ttk.Label(frame_scroll, text=etichetta, wraplength=200).grid(row=riga, column=0, sticky="w", pady=2)
            variabile = tk.StringVar(value=str(alimentazione.get(chiave, "") or ""))
            ttk.Entry(frame_scroll, textvariable=variabile, width=30).grid(row=riga, column=1, pady=2)
            self.variabili[chiave] = variabile
            riga += 1

        barra = ttk.Frame(self)
        barra.pack(side="bottom", fill="x", padx=8, pady=8)
        self.etichetta_conteggi = ttk.Label(barra, text=self._testo_conteggi())
        self.etichetta_conteggi.pack(side="left")
        ttk.Button(barra, text="CANALI...", command=self._apri_canali).pack(side="left", padx=(12, 4))
        ttk.Button(barra, text="NOTE LIBERE...", command=self._apri_note).pack(side="left")
        ttk.Button(barra, text="ANNULLA", command=self.destroy).pack(side="right")
        ttk.Button(barra, text="SALVA", command=self._salva).pack(side="right", padx=4)

    def _testo_conteggi(self):
        return f"Canali: {len(self.canali)} | Note: {len(self.note)}"

    def _apri_canali(self):
        risultato = FinestraElenco(self, "CANALI - " + self.title(), COLONNE_CANALI, CAMPI_CANALE, self.canali).mostra()
        if risultato is not None:
            self.canali = risultato
            self.etichetta_conteggi.configure(text=self._testo_conteggi())

    def _apri_note(self):
        colonne = [("testo", "Nota", 500)]
        campi = [("testo", "Testo della nota")]
        elementi = [{"testo": n.get("testo", "")} for n in self.note]
        risultato = FinestraElenco(self, "NOTE LIBERE - " + self.title(), colonne, campi, elementi).mostra()
        if risultato is not None:
            self.note = risultato
            self.etichetta_conteggi.configure(text=self._testo_conteggi())

    def _numero_o_none(self, testo: str):
        testo = (testo or "").strip()
        if not testo:
            return None
        try:
            return float(testo)
        except ValueError:
            return None

    def _salva(self):
        tipo = self.variabili["tipo"].get().strip()
        identificativo = self.variabili["identificativo"].get().strip()
        if not tipo or not identificativo:
            messagebox.showwarning("Dati mancanti", "Tipo e Identificativo sono obbligatori.", parent=self)
            return

        campi_scheda = {chiave: self.variabili[chiave].get().strip() for chiave, _ in CAMPI_HEADER}
        campi_scheda["ordine_pagina"] = 0

        if self.is_new:
            self.scheda_id = db.add_scheda(**campi_scheda)
        else:
            db.update_scheda(self.scheda_id, **campi_scheda)

        campi_alim_testo = {"alimentazione", "canali_tot", "ampere_max_canale", "ampere_max_bank",
                             "tipo_spina", "qta_spine", "ampere", "numero_alimentatori",
                             "alimentatore_1_watt_amp", "alimentatore_2_watt_amp", "bulbi_per_canale",
                             "canali_x_bank", "bank_x_scheda", "tot_watt", "tot_ampere"}
        campi_alim_numerici = {"altezza", "larghezza", "watt_x_bulbo", "watt_x_canale",
                                "watt_x_bank", "tot_watt_x_scheda"}
        campi_alimentazione = {}
        for chiave, _ in CAMPI_ALIMENTAZIONE:
            valore_grezzo = self.variabili[chiave].get().strip()
            if chiave in campi_alim_numerici:
                campi_alimentazione[chiave] = self._numero_o_none(valore_grezzo)
            else:
                campi_alimentazione[chiave] = valore_grezzo

        db.set_alimentazione(self.scheda_id, **campi_alimentazione)
        db.set_canali(self.scheda_id, self.canali)
        db.set_note_scheda(self.scheda_id, [n.get("testo", "") for n in self.note])

        self.salvato = True
        self.destroy()


class AppSchedeLuci(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LUCI DI NATALE - Schede e canali")
        self.geometry("820x520+300+120")

        colonne = ("identificativo", "tipo", "modello", "facciata", "n_canali", "watt")
        self.albero = ttk.Treeview(self, columns=colonne, show="headings", selectmode="browse")
        intestazioni = {
            "identificativo": ("Identificativo", 160),
            "tipo": ("Tipo", 60),
            "modello": ("Modello", 170),
            "facciata": ("Facciata", 90),
            "n_canali": ("N. Canali", 80),
            "watt": ("Watt Totali", 90),
        }
        for chiave, (titolo, larghezza) in intestazioni.items():
            self.albero.heading(chiave, text=titolo)
            self.albero.column(chiave, width=larghezza, anchor="w")
        self.albero.pack(fill="both", expand=True, padx=8, pady=8)
        self.albero.bind("<Double-1>", lambda e: self._apri_dettaglio())

        frame_bottoni = ttk.Frame(self)
        frame_bottoni.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(frame_bottoni, text="NUOVA SCHEDA", command=self._nuova_scheda).pack(side="left")
        ttk.Button(frame_bottoni, text="APRI DETTAGLIO", command=self._apri_dettaglio).pack(side="left", padx=4)
        ttk.Button(frame_bottoni, text="ELIMINA SCHEDA", command=self._elimina_scheda).pack(side="left")
        ttk.Button(frame_bottoni, text="MEMO GENERALE", command=self._apri_memo_generale).pack(side="right")

        self._aggiorna_griglia()

    def _aggiorna_griglia(self):
        self.albero.delete(*self.albero.get_children())
        for scheda in db.get_schede():
            canali = db.get_canali(scheda["id"])
            alimentazione = db.get_alimentazione(scheda["id"])
            watt = alimentazione["tot_watt"] if alimentazione and alimentazione["tot_watt"] else ""
            self.albero.insert(
                "", "end", iid=str(scheda["id"]),
                values=(scheda["identificativo"], scheda["tipo"], scheda["modello"] or "",
                        scheda["facciata"] or "", len(canali), watt),
            )

    def _scheda_selezionata_id(self):
        selezione = self.albero.selection()
        if not selezione:
            return None
        return int(selezione[0])

    def _nuova_scheda(self):
        finestra = FinestraDettaglioScheda(self, None)
        self.wait_window(finestra)
        if finestra.salvato:
            self._aggiorna_griglia()

    def _apri_dettaglio(self):
        scheda_id = self._scheda_selezionata_id()
        if scheda_id is None:
            return
        finestra = FinestraDettaglioScheda(self, scheda_id)
        self.wait_window(finestra)
        if finestra.salvato:
            self._aggiorna_griglia()

    def _elimina_scheda(self):
        scheda_id = self._scheda_selezionata_id()
        if scheda_id is None:
            return
        scheda = db.get_scheda(scheda_id)
        conferma = messagebox.askyesno(
            "Conferma eliminazione",
            f"Eliminare la scheda '{scheda['identificativo']}' e tutti i suoi dati "
            "(canali, alimentazione, note)?",
            parent=self,
        )
        if conferma:
            db.delete_scheda(scheda_id)
            self._aggiorna_griglia()

    def _apri_memo_generale(self):
        colonne = [("testo", "Promemoria", 500)]
        campi = [("testo", "Testo del promemoria")]
        elementi = [{"testo": m["testo"]} for m in db.get_memo_generale()]
        risultato = FinestraElenco(self, "MEMO GENERALE - Da ricordarsi ogni anno", colonne, campi, elementi).mostra()
        if risultato is not None:
            db.set_memo_generale([r.get("testo", "") for r in risultato])


if __name__ == "__main__":
    app = AppSchedeLuci()
    app.mainloop()
