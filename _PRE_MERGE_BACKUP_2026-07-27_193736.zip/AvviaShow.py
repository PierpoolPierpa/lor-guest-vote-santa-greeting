"""
AvviaShow.py
Avvia VotoShow.py e MotoreShow.py in background (nessuna finestra
visibile). Richiamato da ManagerShow.pyw (pulsante "Avvia ora" o
pianificazione tramite l'Utilita' di Pianificazione di Windows).

Salva il PID di ogni processo avviato in un file: FermaShow.py legge
quei PID per sapere ESATTAMENTE quali processi fermare, senza rischiare
di toccare altri processi Python eventualmente aperti sul PC.

Nota tecnica: i processi figli vengono avviati con python.exe (non
pythonw.exe) perche' VotoShow.py e MotoreShow.py scrivono anche su
console (oltre che su file di log): con pythonw.exe sys.stdout e'
None e quel logging andrebbe in crash. La finestra resta comunque
invisibile grazie al flag CREATE_NO_WINDOW.

Estensione .py (non .pyw): serve per poter essere importato da
ManagerShow.pyw. Quando lo lancia l'Utilita' di Pianificazione, la
finestra resta comunque nascosta perche' li' specifichiamo esplicitamente
pythonw.exe come programma da eseguire.
"""

import subprocess
import sys
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
CARTELLA_2026 = SCRIPT_DIR.parent.parent
FILE_VOTOSHOW = CARTELLA_2026 / "03_SERVER_VOTO" / "VotoShow.py"
FILE_MOTORESHOW = SCRIPT_DIR / "MotoreShow.py"
CARTELLA_LOG = SCRIPT_DIR / "LOG"
FILE_PID_VOTO = CARTELLA_LOG / "pid_votoshow.txt"
FILE_PID_MOTORE = CARTELLA_LOG / "pid_motoreshow.txt"
FILE_LOG_AVVIO = CARTELLA_LOG / "AvviaShow.log"

PYTHON_EXE = Path(sys.executable).parent / "python.exe"
CREATE_NO_WINDOW = 0x08000000
BELOW_NORMAL_PRIORITY_CLASS = 0x00004000


def _log(messaggio: str) -> None:
    CARTELLA_LOG.mkdir(parents=True, exist_ok=True)
    riga = f"{datetime.now():%Y-%m-%d %H:%M:%S} {messaggio}\n"
    with open(FILE_LOG_AVVIO, "a", encoding="utf-8") as f:
        f.write(riga)


def verifica_in_esecuzione(file_pid: Path) -> bool:
    """Vero se il PID salvato in file_pid corrisponde a un processo
    python.exe ancora attivo. Usata anche da ManagerShow.pyw per
    mostrare lo stato acceso/spento nella GUI."""
    if not file_pid.is_file():
        return False
    try:
        pid = int(file_pid.read_text(encoding="utf-8").strip())
    except ValueError:
        return False
    risultato = subprocess.run(
        ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
        capture_output=True, text=True, creationflags=CREATE_NO_WINDOW,
    )
    return "python" in risultato.stdout.lower()


def avvia(percorso_script: Path, file_pid: Path, priorita_bassa: bool = False) -> None:
    """priorita_bassa=True fa partire il processo con priorita' Windows
    "Below Normal": in caso di sovraccarico (es. VotoShow sotto un flood
    di richieste), lo scheduler di Windows favorisce sempre gli altri
    processi sullo stesso PC - in particolare MotoreShow, che pilota le
    luci e non deve mai perdere i tempi per colpa del server di voto."""
    if not percorso_script.is_file():
        _log(f"ERRORE: script non trovato: {percorso_script}")
        return
    if verifica_in_esecuzione(file_pid):
        _log(f"Gia' in esecuzione, salto: {percorso_script.name}")
        return

    flag_creazione = CREATE_NO_WINDOW
    if priorita_bassa:
        flag_creazione |= BELOW_NORMAL_PRIORITY_CLASS

    processo = subprocess.Popen(
        [str(PYTHON_EXE), str(percorso_script)],
        cwd=str(percorso_script.parent),
        creationflags=flag_creazione,
    )
    CARTELLA_LOG.mkdir(parents=True, exist_ok=True)
    file_pid.write_text(str(processo.pid), encoding="utf-8")
    _log(f"Avviato {percorso_script.name} (PID {processo.pid})" + (" [priorita' bassa]" if priorita_bassa else ""))


if __name__ == "__main__":
    _log("=== AvviaShow: avvio richiesto ===")
    avvia(FILE_VOTOSHOW, FILE_PID_VOTO, priorita_bassa=True)
    avvia(FILE_MOTORESHOW, FILE_PID_MOTORE)
