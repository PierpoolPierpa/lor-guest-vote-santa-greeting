"""
ManagerShow.pyw
GUI unificata per gestire lo show: canzoni votabili (aggiungi/modifica/
escludi/rinomina) + programmazione avvio/arresto automatico di
VotoShow.py e MotoreShow.py, con indicatore di stato acceso/spento.

Sostituisce i vecchi GestisciCanzoni.pyw e PianificaShow.pyw (ora unificati
qui in due schede della stessa finestra).

IMPORTANTE: questa GUI non cancella MAI fisicamente file .loredit/audio
dal disco. "Escludere" una canzone significa solo toglierla dalla lista
votabile: le sequenze restano intatte per LOR e si possono reincludere
in qualsiasi momento.

Dopo ogni modifica alle canzoni viene rigenerato catalogo_canzoni.json.
VotoShow.py legge quel file solo all'avvio: se e' gia' in esecuzione
durante lo show, va riavviato perche' le modifiche abbiano effetto.
"""

import configparser
import ctypes
import ctypes.wintypes
import json
import os
import shutil
import subprocess
import sys
import tkinter as tk
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from traduzioni import LINGUA_DEFAULT, testo

try:
    import CostruisciCatalogo as cat
except SystemExit:
    # CostruisciCatalogo.py chiama sys.exit() con un messaggio stampato a
    # console se manca 'mutagen': in un .pyw (nessuna console) quel
    # messaggio sarebbe invisibile, quindi lo intercettiamo qui e offriamo
    # di installarlo da soli usando sys.executable, cosi' va per forza
    # nello stesso identico Python che sta eseguendo questa finestra.
    _radice_temporanea = tk.Tk()
    _radice_temporanea.withdraw()
    _vuole_installare = messagebox.askyesno(
        testo(LINGUA_DEFAULT, "gc_dipendenza_mancante_titolo"),
        testo(LINGUA_DEFAULT, "gc_dipendenza_mancante_testo"),
    )
    if _vuole_installare:
        _risultato = subprocess.run(
            [sys.executable, "-m", "pip", "install", "mutagen"],
            capture_output=True, text=True,
        )
        if _risultato.returncode == 0:
            messagebox.showinfo(
                testo(LINGUA_DEFAULT, "gc_installazione_riuscita_titolo"),
                testo(LINGUA_DEFAULT, "gc_installazione_riuscita_testo"),
            )
        else:
            messagebox.showerror(
                testo(LINGUA_DEFAULT, "gc_installazione_fallita_titolo"),
                testo(LINGUA_DEFAULT, "gc_installazione_fallita_testo", errore=_risultato.stderr[-500:]),
            )
    raise SystemExit(1)

CONFIG_PATH = cat.CONFIG_PATH
SEZIONE_TRIGGER = "TRIGGER_LOR"
SEZIONE_SEQUENZE_LOR = "SEQUENZE_LOR"
SEZIONE_VOTO = "VOTO"
SEZIONE_ORARI = "ORARI"
SEZIONE_PULIZIA = "PULIZIA"

# AvviaShow.py/FermaShow.py/PuliziaPreShow.py vivono in 01_AUTOMAZIONE, non
# nella stessa cartella di questo file: li aggiungiamo al percorso di
# ricerca moduli.
CARTELLA_AUTOMAZIONE = CONFIG_PATH.parent
sys.path.insert(0, str(CARTELLA_AUTOMAZIONE))
import AvviaShow  # noqa: E402
import FermaShow  # noqa: E402
import PuliziaPreShow  # noqa: E402

NOME_TASK_AVVIO = "V1965_Show_Avvio"
NOME_TASK_STOP = "V1965_Show_Stop"
NOME_TASK_PULIZIA = "V1965_Show_Pulizia"
GIORNI_SETTIMANA = ["Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"]
MAPPA_GIORNI_SCHTASKS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]


def leggi_lingua_iniziale() -> str:
    parser = configparser.ConfigParser()
    parser.read(CONFIG_PATH, encoding="utf-8")
    lingua = parser.get(SEZIONE_VOTO, "Lingua_Interfaccia", fallback=LINGUA_DEFAULT).strip().lower()
    return lingua if lingua in ("it", "en") else LINGUA_DEFAULT


# ----------------------------------------------------------------------
# Lettura/scrittura dirette del CONFIGURAZIONE_SHOW.ini
# ----------------------------------------------------------------------
def carica_parser() -> configparser.ConfigParser:
    parser = configparser.ConfigParser()
    parser.read(CONFIG_PATH, encoding="utf-8")
    for sezione in ("PERCORSI", SEZIONE_VOTO, SEZIONE_TRIGGER, SEZIONE_SEQUENZE_LOR, SEZIONE_ORARI):
        if sezione not in parser:
            parser[sezione] = {}
    return parser


def salva_parser(parser: configparser.ConfigParser) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        parser.write(f)


def leggi_cartella_sequenze(parser: configparser.ConfigParser) -> Path:
    grezzo = parser.get("PERCORSI", "Cartella_Sequenze", fallback="").strip()
    return (cat.CARTELLA_AUTOMAZIONE / grezzo).resolve()


def leggi_cartelle_escluse(parser: configparser.ConfigParser) -> set:
    grezzo = parser.get(SEZIONE_VOTO, "Cartelle_Escluse", fallback="").strip()
    return {c.strip() for c in grezzo.split(",") if c.strip()}


def scrivi_cartelle_escluse(parser: configparser.ConfigParser, cartelle_escluse: set) -> None:
    parser.set(SEZIONE_VOTO, "Cartelle_Escluse", ", ".join(sorted(cartelle_escluse)))


def leggi_trigger(parser: configparser.ConfigParser, id_canzone: str) -> str:
    return parser.get(SEZIONE_TRIGGER, id_canzone, fallback="")


def scrivi_trigger(parser: configparser.ConfigParser, id_canzone: str, indirizzo: str) -> None:
    if indirizzo.strip():
        parser.set(SEZIONE_TRIGGER, id_canzone, indirizzo.strip())
    elif parser.has_option(SEZIONE_TRIGGER, id_canzone):
        parser.remove_option(SEZIONE_TRIGGER, id_canzone)


def leggi_nome_lor(parser: configparser.ConfigParser, id_canzone: str) -> str:
    return parser.get(SEZIONE_SEQUENZE_LOR, id_canzone, fallback="")


def scrivi_nome_lor(parser: configparser.ConfigParser, id_canzone: str, nome_lor: str) -> None:
    if nome_lor.strip():
        parser.set(SEZIONE_SEQUENZE_LOR, id_canzone, nome_lor.strip())
    elif parser.has_option(SEZIONE_SEQUENZE_LOR, id_canzone):
        parser.remove_option(SEZIONE_SEQUENZE_LOR, id_canzone)


def leggi_sequenze_da_lor(parser: configparser.ConfigParser) -> list:
    """Interroga in diretta l'API di LOR (GET /v1/player/mainSequences) e
    ritorna i nomi esatti delle sequenze nel Main, nell'ordine in cui LOR
    le restituisce (che rispecchia il loro ordine nello show). Solleva
    RuntimeError con un messaggio leggibile se LOR non e' raggiungibile."""
    porta_api = parser.getint(SEZIONE_TRIGGER, "Porta_API_LOR", fallback=8001)
    url = f"http://127.0.0.1:{porta_api}/v1/player/mainSequences"
    try:
        with urllib.request.urlopen(url, timeout=4) as risposta:
            dati = json.loads(risposta.read())
    except (urllib.error.URLError, TimeoutError, OSError) as errore:
        raise RuntimeError(str(errore)) from errore

    voci = dati if isinstance(dati, list) else (dati or {}).get("value", [])
    nomi = [voce.get("name", "").strip() for voce in voci if voce.get("name", "").strip()]
    return nomi


def rigenera_catalogo_sicuro(lingua: str) -> tuple:
    """Richiama CostruisciCatalogo.costruisci_catalogo() proteggendosi dal
    fatto che le sue funzioni interne possono chiamare sys.exit() in caso
    di errore grave (comportamento pensato per l'uso da riga di comando,
    qui invece va trasformato in un messaggio senza chiudere la GUI)."""
    try:
        cat.costruisci_catalogo()
        return True, None
    except SystemExit:
        return False, testo(lingua, "gc_errore_config_generico")
    except Exception as errore:
        return False, str(errore)


# ----------------------------------------------------------------------
# Anteprima di una cartella-sequenza (solo lettura, nessuna copia file:
# quella la fa solo rigenera_catalogo_sicuro())
# ----------------------------------------------------------------------
def anteprima_sequenza(cartella: Path) -> dict:
    id_canzone = cat.crea_id(cartella.name)
    percorso_audio = cat.trova_primo_file(cartella, cat.ESTENSIONI_AUDIO)

    if percorso_audio is None:
        return {
            "id": id_canzone, "cartella": cartella, "titolo": cartella.name,
            "artista": "", "durata_testo": "--:--", "ha_audio": False,
            "percorso_audio": None, "percorso_copertina": None,
        }

    titolo, artista, durata = cat.leggi_metadati_audio(percorso_audio, cartella.name)
    percorso_copertina = cat.trova_primo_file(cartella, cat.ESTENSIONI_IMMAGINE)
    return {
        "id": id_canzone, "cartella": cartella, "titolo": titolo, "artista": artista,
        "durata_testo": cat.formatta_durata(durata), "ha_audio": True,
        "percorso_audio": percorso_audio, "percorso_copertina": percorso_copertina,
    }


# ----------------------------------------------------------------------
# Utilita' di Pianificazione di Windows (schtasks)
# ----------------------------------------------------------------------
CREATE_NO_WINDOW = 0x08000000


def _task_esiste(nome: str) -> bool:
    risultato = subprocess.run(
        ["schtasks", "/query", "/tn", nome],
        capture_output=True, text=True, creationflags=CREATE_NO_WINDOW,
    )
    return risultato.returncode == 0


def _processo_e_elevato() -> bool:
    """Vero se ManagerShow.pyw sta girando ADESSO con privilegi elevati
    (avviato con 'Esegui come amministratore'). Windows nega la creazione
    di un task /RL HIGHEST se il processo che lo crea non e' gia' lui
    stesso elevato in questo momento - non basta che l'account sia
    amministratore, serve che sia elevato ora."""
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except OSError:
        return False


def _crea_task(nome: str, percorso_script: Path, giorni_schtasks: list, orario: str) -> tuple:
    pythonw = Path(sys.executable).parent / "pythonw.exe"
    comando = [
        "schtasks", "/create", "/tn", nome, "/sc", "weekly",
        "/d", ",".join(giorni_schtasks), "/st", orario,
        "/tr", f'"{pythonw}" "{percorso_script}"',
        "/f",
    ]
    if _processo_e_elevato():
        comando += ["/rl", "highest"]
    risultato = subprocess.run(comando, capture_output=True, text=True, creationflags=CREATE_NO_WINDOW)
    return risultato.returncode == 0, (risultato.stderr.strip() or risultato.stdout.strip())


def _elimina_task(nome: str) -> tuple:
    risultato = subprocess.run(
        ["schtasks", "/delete", "/tn", nome, "/f"],
        capture_output=True, text=True, creationflags=CREATE_NO_WINDOW,
    )
    return risultato.returncode == 0, (risultato.stderr.strip() or risultato.stdout.strip())


# ----------------------------------------------------------------------
# Lancio di Schede Luci (tool separato per l'inventario schede/canali/
# alimentazione - vive in 04_SCHEDE_LUCI, fuori da questa cartella)
# ----------------------------------------------------------------------
PERCORSO_SCHEDE_LUCI = CARTELLA_AUTOMAZIONE.parent / "04_SCHEDE_LUCI" / "SchedeLuci.pyw"


def apri_schede_luci() -> None:
    if not PERCORSO_SCHEDE_LUCI.exists():
        messagebox.showerror(
            "Schede Luci non trovato",
            f"Non trovo {PERCORSO_SCHEDE_LUCI}",
        )
        return
    pythonw = Path(sys.executable).parent / "pythonw.exe"
    subprocess.Popen([str(pythonw), str(PERCORSO_SCHEDE_LUCI)], cwd=str(PERCORSO_SCHEDE_LUCI.parent))


def _calcola_orario_anticipato(orario_hhmm: str, minuti_anticipo: int) -> str:
    base = datetime.strptime(orario_hhmm.strip(), "%H:%M")
    anticipato = base - timedelta(minutes=minuti_anticipo)
    return anticipato.strftime("%H:%M")


# ----------------------------------------------------------------------
# Finestra di dialogo per Aggiungi/Modifica canzone
# ----------------------------------------------------------------------
class DialogoCanzone(tk.Toplevel):
    def __init__(self, padre, cartella_sequenze: Path, lingua: str, dati_esistenti: dict = None):
        super().__init__(padre)
        self.cartella_sequenze = cartella_sequenze
        self.lingua = lingua
        self.dati_esistenti = dati_esistenti
        self.risultato_salvato = False

        self.title(
            testo(lingua, "gc_titolo_dialogo_modifica") if dati_esistenti
            else testo(lingua, "gc_titolo_dialogo_aggiungi")
        )
        self.resizable(False, False)
        self.transient(padre)
        self.grab_set()

        self.percorso_audio_scelto = dati_esistenti["percorso_audio"] if dati_esistenti else None
        self.percorso_copertina_scelta = dati_esistenti["percorso_copertina"] if dati_esistenti else None

        self._costruisci_campi()

    def _t(self, chiave: str, **valori) -> str:
        return testo(self.lingua, chiave, **valori)

    def _costruisci_campi(self):
        padding = {"padx": 8, "pady": 4}
        modifica = self.dati_esistenti is not None

        ttk.Label(self, text=self._t("gc_campo_nome")).grid(row=0, column=0, sticky="w", **padding)
        self.var_nome = tk.StringVar(value=self.dati_esistenti["cartella"].name if modifica else "")
        entry_nome = ttk.Entry(self, textvariable=self.var_nome, width=40)
        entry_nome.grid(row=0, column=1, columnspan=2, sticky="w", **padding)

        ttk.Label(self, text=self._t("gc_campo_audio")).grid(row=1, column=0, sticky="w", **padding)
        self.var_audio = tk.StringVar(
            value=self.percorso_audio_scelto.name if self.percorso_audio_scelto else self._t("gc_nessuno_scelto")
        )
        ttk.Label(self, textvariable=self.var_audio, width=32).grid(row=1, column=1, sticky="w", **padding)
        ttk.Button(self, text=self._t("gc_sfoglia_audio"), command=self._sfoglia_audio).grid(row=1, column=2, **padding)

        ttk.Label(self, text=self._t("gc_campo_titolo")).grid(row=2, column=0, sticky="w", **padding)
        self.var_titolo = tk.StringVar(value=self.dati_esistenti["titolo"] if modifica else "")
        ttk.Entry(self, textvariable=self.var_titolo, width=40).grid(row=2, column=1, columnspan=2, sticky="w", **padding)

        ttk.Label(self, text=self._t("gc_campo_artista")).grid(row=3, column=0, sticky="w", **padding)
        self.var_artista = tk.StringVar(value=self.dati_esistenti["artista"] if modifica else "")
        ttk.Entry(self, textvariable=self.var_artista, width=40).grid(row=3, column=1, columnspan=2, sticky="w", **padding)

        ttk.Label(self, text=self._t("gc_campo_copertina")).grid(row=4, column=0, sticky="w", **padding)
        self.var_copertina = tk.StringVar(
            value=self.percorso_copertina_scelta.name if self.percorso_copertina_scelta else self._t("gc_nessuna")
        )
        ttk.Label(self, textvariable=self.var_copertina, width=32).grid(row=4, column=1, sticky="w", **padding)
        ttk.Button(self, text=self._t("gc_sfoglia_copertina"), command=self._sfoglia_copertina).grid(row=4, column=2, **padding)

        ttk.Label(self, text=self._t("gc_campo_trigger")).grid(row=5, column=0, sticky="w", **padding)
        trigger_attuale = ""
        if modifica:
            parser = carica_parser()
            trigger_attuale = leggi_trigger(parser, self.dati_esistenti["id"])
        self.var_trigger = tk.StringVar(value=trigger_attuale)
        self.combo_trigger = ttk.Combobox(
            self, textvariable=self.var_trigger, width=37, values=self._genera_suggerimenti_trigger(),
        )
        self.combo_trigger.grid(row=5, column=1, columnspan=2, sticky="w", **padding)

        ttk.Label(self, text=self._t("gc_campo_nome_lor")).grid(row=6, column=0, sticky="w", **padding)
        nome_lor_attuale = ""
        if modifica:
            parser = carica_parser()
            nome_lor_attuale = leggi_nome_lor(parser, self.dati_esistenti["id"])
        self.var_nome_lor = tk.StringVar(value=nome_lor_attuale)
        self.combo_nome_lor = ttk.Combobox(self, textvariable=self.var_nome_lor, width=37, values=())
        self.combo_nome_lor.grid(row=6, column=1, sticky="w", **padding)
        ttk.Button(self, text=self._t("gc_bottone_carica_da_lor"), command=self._carica_sequenze_lor).grid(row=6, column=2, **padding)

        frame_bottoni = ttk.Frame(self)
        frame_bottoni.grid(row=7, column=0, columnspan=3, sticky="e", padx=8, pady=10)
        ttk.Button(frame_bottoni, text=self._t("gc_bottone_annulla"), command=self.destroy).grid(row=0, column=0, padx=4)
        ttk.Button(frame_bottoni, text=self._t("gc_bottone_salva"), command=self._salva).grid(row=0, column=1, padx=4)

        entry_nome.focus_set()

    def _sfoglia_audio(self):
        percorso = filedialog.askopenfilename(
            title=self._t("gc_scegli_audio"),
            filetypes=[
                (self._t("gc_filtro_audio"), " ".join(f"*{e}" for e in cat.ESTENSIONI_AUDIO)),
                (self._t("gc_filtro_tutti"), "*.*"),
            ],
        )
        if not percorso:
            return
        self.percorso_audio_scelto = Path(percorso)
        self.var_audio.set(self.percorso_audio_scelto.name)

        if not self.var_titolo.get().strip() and not self.var_artista.get().strip():
            titolo, artista, _ = cat.leggi_metadati_audio(self.percorso_audio_scelto, self.percorso_audio_scelto.stem)
            self.var_titolo.set(titolo)
            self.var_artista.set(artista)

    def _sfoglia_copertina(self):
        percorso = filedialog.askopenfilename(
            title=self._t("gc_scegli_copertina"),
            filetypes=[
                (self._t("gc_filtro_immagini"), " ".join(f"*{e}" for e in cat.ESTENSIONI_IMMAGINE)),
                (self._t("gc_filtro_tutti"), "*.*"),
            ],
        )
        if percorso:
            self.percorso_copertina_scelta = Path(percorso)
            self.var_copertina.set(self.percorso_copertina_scelta.name)

    def _genera_suggerimenti_trigger(self) -> list:
        """Genera in locale una lista di codici 'Regular-01-N' crescenti da
        proporre nella tendina del trigger: non c'e' nessuna API di LOR che
        elenchi i trigger esistenti, quindi la lista si basa sul numero di
        sequenze gia' salvate in 02_SEQUENZE (+ qualche numero libero in
        piu'), cosi' non serve scriverli a mano."""
        try:
            numero_sequenze = sum(1 for p in self.cartella_sequenze.iterdir() if p.is_dir())
        except OSError:
            numero_sequenze = 0
        ultimo = max(numero_sequenze, 1) + 3
        return [f"Regular-01-{i}" for i in range(1, ultimo + 1)]

    def _carica_sequenze_lor(self):
        parser = carica_parser()
        try:
            nomi = leggi_sequenze_da_lor(parser)
        except RuntimeError as errore:
            messagebox.showerror(
                self._t("gc_lor_non_raggiungibile_titolo"),
                self._t("gc_lor_non_raggiungibile_testo", errore=errore),
            )
            return

        if not nomi:
            messagebox.showinfo(self._t("gc_lor_nessuna_sequenza_titolo"), self._t("gc_lor_nessuna_sequenza_testo"))
            return

        self.combo_nome_lor.configure(values=nomi)
        self.combo_nome_lor.tk.call("ttk::combobox::Post", self.combo_nome_lor)

    def _salva(self):
        nome = self.var_nome.get().strip()
        titolo = self.var_titolo.get().strip()
        artista = self.var_artista.get().strip()
        trigger = self.var_trigger.get().strip()
        nome_lor = self.var_nome_lor.get().strip()
        modifica = self.dati_esistenti is not None

        if not nome:
            messagebox.showerror(self._t("gc_errore_campo_obbligatorio"), self._t("gc_errore_nome_vuoto"))
            return
        if not titolo:
            messagebox.showerror(self._t("gc_errore_campo_obbligatorio"), self._t("gc_errore_titolo_vuoto"))
            return

        cartella_originale = self.dati_esistenti["cartella"] if modifica else None
        rinominata = modifica and cartella_originale.name != nome
        cartella_destinazione = self.cartella_sequenze / nome

        if (not modifica or rinominata) and cartella_destinazione.exists():
            messagebox.showerror(self._t("gc_nome_gia_usato_titolo"), self._t("gc_nome_gia_usato_testo", nome=nome))
            return
        if not modifica and self.percorso_audio_scelto is None:
            messagebox.showerror(self._t("gc_audio_mancante_titolo"), self._t("gc_audio_mancante_testo"))
            return

        if rinominata and not messagebox.askyesno(
            self._t("gc_conferma_rinomina_titolo"),
            self._t("gc_conferma_rinomina_testo", vecchio=cartella_originale.name, nuovo=nome),
        ):
            return

        try:
            if rinominata:
                cartella_originale.rename(cartella_destinazione)
                if self.dati_esistenti.get("percorso_audio") is not None:
                    self.dati_esistenti["percorso_audio"] = cartella_destinazione / self.dati_esistenti["percorso_audio"].name
                if self.dati_esistenti.get("percorso_copertina") is not None:
                    self.dati_esistenti["percorso_copertina"] = cartella_destinazione / self.dati_esistenti["percorso_copertina"].name

            cartella_destinazione.mkdir(parents=True, exist_ok=True)

            audio_precedente = self.dati_esistenti.get("percorso_audio") if modifica else None
            if not modifica or self.percorso_audio_scelto != audio_precedente:
                if self.percorso_audio_scelto is not None:
                    file_audio_finale = cartella_destinazione / self.percorso_audio_scelto.name
                    if self.percorso_audio_scelto != file_audio_finale:
                        shutil.copyfile(self.percorso_audio_scelto, file_audio_finale)
                    if audio_precedente is not None and audio_precedente != file_audio_finale and audio_precedente.exists():
                        audio_precedente.unlink()
                else:
                    file_audio_finale = None
            else:
                file_audio_finale = audio_precedente

            if file_audio_finale is not None:
                cat.scrivi_metadati_audio(file_audio_finale, titolo, artista)

            copertina_precedente = self.dati_esistenti.get("percorso_copertina") if modifica else None
            if self.percorso_copertina_scelta is not None and self.percorso_copertina_scelta != copertina_precedente:
                if copertina_precedente is not None and copertina_precedente.exists():
                    copertina_precedente.unlink()

                file_copertina_finale = cartella_destinazione / (
                    "copertina" + self.percorso_copertina_scelta.suffix.lower()
                )
                if self.percorso_copertina_scelta != file_copertina_finale:
                    shutil.copyfile(self.percorso_copertina_scelta, file_copertina_finale)

            id_canzone = cat.crea_id(nome)
            parser = carica_parser()

            if rinominata:
                vecchio_id = cat.crea_id(cartella_originale.name)
                trigger_precedente = leggi_trigger(parser, vecchio_id)
                scrivi_trigger(parser, vecchio_id, "")
                scrivi_nome_lor(parser, vecchio_id, "")

                cartelle_escluse = leggi_cartelle_escluse(parser)
                if any(c.lower() == cartella_originale.name.lower() for c in cartelle_escluse):
                    cartelle_escluse = {c for c in cartelle_escluse if c.lower() != cartella_originale.name.lower()}
                    cartelle_escluse.add(nome)
                    scrivi_cartelle_escluse(parser, cartelle_escluse)
            else:
                trigger_precedente = leggi_trigger(parser, id_canzone)

            scrivi_trigger(parser, id_canzone, trigger)
            scrivi_nome_lor(parser, id_canzone, nome_lor)
            salva_parser(parser)

            ok, errore = rigenera_catalogo_sicuro(self.lingua)
            if not ok:
                messagebox.showwarning(
                    self._t("gc_salvato_con_avvisi_titolo"),
                    self._t("gc_salvato_con_avvisi_testo", errore=errore),
                )

            if trigger and trigger != trigger_precedente:
                messagebox.showinfo(
                    self._t("gc_promemoria_titolo"),
                    self._t("gc_promemoria_testo", trigger=trigger, titolo=titolo, nome=nome),
                )

            self.risultato_salvato = True
            self.destroy()

        except OSError as errore:
            messagebox.showerror(self._t("gc_errore_titolo"), self._t("gc_errore_salvataggio_file", errore=errore))


# ----------------------------------------------------------------------
# Finestra Guida (companion window agganciata alla finestra principale)
# ----------------------------------------------------------------------
TESTO_GUIDA = {
    "it": {
        "titolo": "Guida - Programmazione",
        "corpo": """COSA FA QUESTA SCHEDA

STATO ATTUALE
Due pallini mostrano se VotoShow.py (il server di voto) e MotoreShow.py (il controllo pre-volo) sono in esecuzione in questo momento: verde = acceso, rosso = spento. "Avvia ora"/"Stop ora" fanno partire o fermare SOLO il sistema di voto, a mano, senza aspettare l'orario programmato - utile per test o emergenze. IMPORTANTE: questi pulsanti non toccano LOR in nessun modo - non accendono ne' spengono le luci/la musica, che LOR gestisce sempre da solo secondo il proprio orario interno, indipendente da questa GUI.

ATTENZIONE - ManagerShow e VotoShow sono DUE programmi separati e indipendenti. Chiudere e riaprire questa finestra (ManagerShow) NON tocca VotoShow in nessun modo: se era acceso resta acceso esattamente come prima, il pallino verde dice solo la verita' su quel processo, che va avanti per conto suo. Se hai cambiato qualcosa nella configurazione che VotoShow deve rileggere (es. il campo "Nome in LOR" di una canzone, nella scheda Canzoni), quella modifica NON si applica da sola: serve fermarlo e farlo ripartire davvero con "Stop ora" e poi "Avvia ora" (o aspettare il prossimo avvio pianificato). VotoShow.py legge la sua configurazione e il catalogo canzoni SOLO all'avvio, mai mentre gira.

ORARI
Orario in cui il sistema di voto (VotoShow.py) deve accendersi/spegnersi da solo ogni giorno. IMPORTANTE: deve combaciare con lo show luminoso di LOR (quello dentro Sequencer/Show Player) - sono due pianificazioni separate (questa qui, del sistema di voto, e quella dentro LOR, dello show vero e proprio) che vanno tenute allineate a mano. Meglio mettere l'Accensione qualche minuto PRIMA dell'orario schedulato in LOR (vedi il box Pulizia qui sotto): cosi' il sistema di voto e' gia' su e pronto quando lo show di LOR parte davvero, invece di rischiare che le prime canzoni partano senza che gli ospiti possano ancora votare.

GIORNI ATTIVI
In quali giorni della settimana il sistema di voto deve accendersi da solo. Se un giorno non e' spuntato, quel giorno VotoShow.py non parte anche se dentro l'orario configurato - controlla che combaci con i giorni in cui lo show di LOR e' programmato per andare in onda.

PULIZIA AUTOMATICA (PRE-SHOW LOR - PRE-VOTO)
Il PC si pulisce da solo (Chrome, cache/temp, programmi che scegli tu) un certo numero di minuti PRIMA dell'Orario Accensione - quanti minuti lo decidi qui. Questo pero' succede in automatico SOLO se hai premuto "Pianifica Win Auto" nel box qui sotto: se non l'hai premuto, la pulizia automatica non parte mai da sola. Il pulsante "Pulisci ora" e' invece un'azione separata e solo manuale, sempre disponibile su richiesta. Per tutti i dettagli vedi il pulsante "Guida pulizia" dentro quel box.

STATO PIANIFICAZIONE
Mostra se la pianificazione di Windows e' attiva. "Salva orari" scrive gli orari nell'ini senza toccare Windows. "Pianifica Win Auto" registra 3 attivita' nella Utilita' di Pianificazione di Windows che faranno partire/fermare da sole il sistema di voto agli orari scelti (LOR resta sempre gestito a parte, dal proprio schedule interno); una volta attiva, lo stesso pulsante diventa "Rimuovi Win Auto" per cancellare quelle 3 attivita' (il sistema di voto smette di partire da solo, ma non cancella nulla dal disco, e LOR continua a funzionare come sempre).

IMPORTANTE: scrivere gli orari nei campi qui sopra (anche con "Salva orari") non fa scattare nulla da solo - e' solo un dato salvato. E anche "Pianifica Win Auto" non ha nessun effetto immediato: registra il task per il FUTURO, al prossimo orario utile. Se lo premi quando l'orario di Spegnimento di oggi e' gia' passato, il sistema di voto NON si ferma subito - restera' acceso come adesso e si fermera' da solo al prossimo orario schedulato (es. stasera, se oggi e' tra i Giorni Attivi). Per fermarlo SUBITO serve comunque "Stop ora", sono due azioni separate.


--- GUIDA TECNICA (come gira davvero) ---

Ogni orario in questa scheda viene scritto in CONFIGURAZIONE_SHOW.ini (sezioni [ORARI] e [PULIZIA]), il file centrale che tutti gli script Python rileggono a ogni avvio.

"Pianifica Win Auto" chiama 'schtasks' di Windows per creare 3 attivita' pianificate, nei giorni della settimana selezionati:
  - V1965_Show_Pulizia -> esegue PuliziaPreShow.py all'orario calcolato (accensione meno i minuti di anticipo)
  - V1965_Show_Avvio   -> esegue AvviaShow.py all'orario di accensione
  - V1965_Show_Stop    -> esegue FermaShow.py all'orario di spegnimento

AvviaShow.py fa partire due processi: MotoreShow.py (una sentinella pre-volo: controlla che tutto sia pronto, poi si chiude da sola, non resta in esecuzione) e VotoShow.py (il vero server di voto, resta acceso finche' non arriva FermaShow.py o lo fermi tu a mano).

VotoShow.py fa due cose in parallelo: (1) espone la pagina di richiesta su http://<ip>:8080 per gli ospiti dal telefono; (2) tiene un thread ("ponte con LOR") che ogni 3 secondi chiede all'API REST di LOR (porta 8001, nessuna configurazione extra serve dentro LOR) quale sequenza sta suonando e quanto manca alla fine.

Le richieste sono cumulative: ogni telefono puo' cambiare richiesta quante volte vuole (vale l'ultima inviata), e quando mancano 6 secondi alla fine si conta quante persone hanno chiesto ciascuna sequenza in questo turno - vince quella con piu' richieste (in caso di pareggio in testa, o zero richieste, non si fa nulla e la scaletta normale di LOR prosegue).

Quando c'e' un vincitore chiaro, VotoShow.py memorizza anche il resto della classifica di quel turno (es. 5 richieste per la prima, 3 per la seconda, 2 per la terza): se il turno seguente non riceve NESSUNA nuova richiesta, invece di lasciar perdere si manda in coda la prossima voce di quella classifica salvata, poi la successiva, finche' non si esaurisce o arrivano richieste fresche. Le richieste nuove hanno sempre la precedenza: appena arrivano, la classifica salvata viene scartata e si riparte da zero con il nuovo vincitore.

RETE E ACCESSO OSPITI
Il telefono degli ospiti deve stare sulla STESSA rete WiFi di casa del PC che fa girare VotoShow.py (raggiungere l'IP del PC sulla porta 8080). Se il router ha una rete "ospiti" separata va bene usarla, ma occhio alla "client isolation" (isolamento dei dispositivi tra loro): se e' attiva, il telefono non riesce a raggiungere il PC anche se e' sulla rete giusta - va disattivata per questo uso. Meglio se la rete ospiti e' aperta (senza password): chi passa vicino a casa si collega subito senza doverti chiedere nulla. Per non far scrivere l'indirizzo IP a mano su ogni telefono, il modo piu' comodo e' generare un codice QR che punta a http://<ip>:8080 (con un generatore QR gratuito online) e stamparlo o appenderlo vicino allo show: gli ospiti inquadrano il QR con la fotocamera e la pagina si apre da sola.

I pallini di stato qui sopra controllano solo se un processo con quel nome (VotoShow.py / MotoreShow.py) e' in esecuzione su Windows in questo momento - non parlano con l'API di LOR, solo con l'elenco processi del sistema operativo.""",
    },
    "en": {
        "titolo": "Guide - Scheduling",
        "corpo": """WHAT THIS TAB DOES

CURRENT STATUS
Two dots show whether VotoShow.py (the voting server) and MotoreShow.py (the pre-flight check) are currently running: green = on, red = off. "Start now"/"Stop now" start or stop ONLY the voting system, manually, without waiting for the scheduled time - useful for testing or emergencies. IMPORTANT: these buttons don't touch LOR in any way - they don't turn the lights/music on or off, LOR always manages that on its own, on its own internal schedule, independent of this GUI.

WARNING - ManagerShow and VotoShow are TWO separate, independent programs. Closing and reopening this window (ManagerShow) does NOT touch VotoShow in any way: if it was running, it keeps running exactly as before, the green dot is just telling the truth about that process, which carries on by itself. If you changed something in the configuration that VotoShow needs to re-read (e.g. a song's "Name in LOR" field, in the Songs tab), that change does NOT apply on its own: you need to actually stop it and start it again with "Stop now" then "Start now" (or wait for the next scheduled start). VotoShow.py reads its configuration and song catalog ONLY at startup, never while running.

SCHEDULE
Start and stop time for the voting system (VotoShow.py) to turn itself on/off every day. IMPORTANT: this must match LOR's own light show (the one inside Sequencer/Show Player) - these are two separate schedules (this one, for the voting system, and LOR's own, for the actual show) that must be kept aligned by hand. It's best to set Start a few minutes BEFORE the time scheduled in LOR (see the Cleanup box below): that way the voting system is already up and ready when LOR's show actually starts, instead of risking the first songs playing before guests can vote yet.

ACTIVE DAYS
Which days of the week the voting system should turn on by itself. If a day is unchecked, VotoShow.py doesn't start that day even within the configured hours - make sure it matches the days LOR's show is scheduled to run.

AUTOMATIC CLEANUP (PRE-SHOW LOR - PRE-VOTE)
The PC cleans itself (Chrome, cache/temp, programs you choose) a number of minutes BEFORE Start time - you choose how many here. This only happens automatically if you've pressed "Schedule Win Auto" in the box below: if you haven't, automatic cleanup never runs on its own. The "Clean now" button is a separate, manual-only action, always available on demand. See the "Cleanup guide" button inside that box for all the details.

SCHEDULE STATUS
Shows whether Windows scheduling is active. "Save times" writes the times to the ini without touching Windows. "Schedule Win Auto" registers 3 tasks in Windows Task Scheduler that will start/stop the voting system on their own at the chosen times (LOR is always managed separately, by its own internal schedule); once active, the same button becomes "Remove Win Auto" to delete those 3 tasks (the voting system stops starting on its own, but nothing is deleted from disk, and LOR keeps working as usual).

IMPORTANT: typing times in the fields above (even with "Save times") doesn't trigger anything by itself - it's just saved data. And "Schedule Win Auto" has no immediate effect either: it registers the task for the FUTURE, at the next matching time. If you press it when today's Stop time has already passed, the voting system does NOT stop right away - it stays on as it is now and will stop on its own at the next scheduled time (e.g. tonight, if today is one of the Active Days). To stop it RIGHT NOW you still need "Stop now" - they are two separate actions.


--- TECHNICAL GUIDE (how it actually runs) ---

Every time in this tab is written to CONFIGURAZIONE_SHOW.ini (sections [ORARI] and [PULIZIA]), the central file every Python script re-reads on every start.

"Schedule Win Auto" calls Windows 'schtasks' to create 3 scheduled tasks, on the selected weekdays:
  - V1965_Show_Pulizia -> runs PuliziaPreShow.py at the computed time (start time minus the lead minutes)
  - V1965_Show_Avvio   -> runs AvviaShow.py at start time
  - V1965_Show_Stop    -> runs FermaShow.py at stop time

AvviaShow.py starts two processes: MotoreShow.py (a one-shot pre-flight sentinel: checks everything is ready, then closes itself, it does not stay running) and VotoShow.py (the actual voting server, stays on until FermaShow.py runs or you stop it manually).

VotoShow.py does two things in parallel: (1) serves the request page at http://<ip>:8080 for guests on their phone; (2) runs a thread (the "LOR bridge") that every 3 seconds asks LOR's REST API (port 8001, no extra setup needed inside LOR) which sequence is playing and how much time is left.

Requests are cumulative: each phone can change its request as many times as it wants (the last one sent counts), and when 6 seconds remain it counts how many people asked for each sequence this turn - the one with the most requests wins (on a tie at the top, or zero requests, nothing happens and LOR's normal playlist continues).

When there's a clear winner, VotoShow.py also remembers the rest of that turn's ranking (e.g. 5 requests for the first, 3 for the second, 2 for the third): if the following turn gets NO new requests at all, instead of giving up it queues the next entry from that saved ranking, then the one after, until it runs out or fresh requests arrive. New requests always take priority: as soon as they arrive, the saved ranking is discarded and it starts over from the new winner.

NETWORK AND GUEST ACCESS
Guests' phones must be on the SAME home WiFi network as the PC running VotoShow.py (able to reach the PC's IP on port 8080). If the router has a separate "guest" network that's fine to use, but watch out for "client isolation" (devices kept from reaching each other): if it's on, the phone can't reach the PC even though it's on the right network - turn it off for this to work. It's best if the guest network is open (no password): anyone nearby connects right away without having to ask you anything. To avoid guests typing the IP address by hand on every phone, the easiest way is to generate a QR code pointing to http://<ip>:8080 (using any free online QR generator) and print it or hang it near the show: guests scan it with their phone camera and the page opens by itself.

The status dots above only check whether a process with that name (VotoShow.py / MotoreShow.py) is currently running on Windows - they don't talk to LOR's API, only to the operating system's process list.""",
    },
}

TESTO_GUIDA_PULIZIA = {
    "it": {
        "titolo": "Guida - Pulizia automatica",
        "corpo": """LA PULIZIA E' AUTOMATICA, NON MANUALE

Questo box configura cosa succede da solo ogni giorno, un tot di minuti PRIMA dell'Orario Accensione - non serve premere nulla ogni volta. Una volta premuto "Pianifica Win Auto" nel box Stato Pianificazione, Windows esegue la pulizia da solo, tutti i giorni schedulati, senza che tu debba ricordartene.

Il pulsante "Pulisci ora" NON e' quello automatico: serve solo per provare subito la pulizia (test) o per farla su richiesta in un momento qualsiasi - va premuto a mano, non parte mai da solo in base a orario/giorni.

COSA PULISCE
- Chiude Chrome, se la casella "Chiudi Chrome" e' spuntata (libera RAM).
- Svuota i file temporanei di Windows e SOLO la cache di Chrome, se "Svuota file temporanei e cache di Chrome" e' spuntata (mai password/preferiti/cronologia).
- Chiude anche i "Programmi da chiudere in automatico" che aggiungi tu col pulsante "Aggiungi...": si apre una ricerca file per scegliere l'eseguibile esatto (anche su un altro disco), non serve scrivere nulla a mano.

CONFERMA PRIMA DI CHIUDERE
Prima di chiudere Chrome o un qualsiasi programma della lista, compare sempre un popup di conferma con Si'/No, cosi' non si chiude niente all'improvviso se qualcuno lo sta usando. Il popup ha un conto alla rovescia di 20 secondi: se nessuno risponde (es. pulizia notturna con nessuno davanti al PC), di default NON lo chiude - non blocca la pulizia in eterno, ma nemmeno forza la chiusura senza permesso.

AGGIORNAMENTI WINDOWS - IMPORTANTE
La casella "Blocca aggiornamenti Windows" prova a fermare Windows Update in automatico ogni volta che parte la pulizia, cosi' non scatta un riavvio o un'installazione a sorpresa mentre lo show e' in corso. Perche' funzioni davvero, i 3 task pianificati devono essere creati con i privilegi piu' alti disponibili - e QUESTO RICHIEDE CHE MANAGERSHOW.PYW SIA GIA' AVVIATO CON "ESEGUI COME AMMINISTRATORE" NEL MOMENTO STESSO IN CUI PREMI "PIANIFICA WIN AUTO" (ManagerShow ora prova a rilanciarsi da solo elevato ad ogni avvio, chiedendo conferma con il prompt di Windows). Non basta che l'account sia amministratore: se ManagerShow non e' elevato in quel momento, Windows nega la creazione dei task con quei privilegi (errore "Accesso negato"), quindi i task vengono creati comunque ma con permessi normali, e il blocco automatico semplicemente non fara' nulla - non rompe la pianificazione, ma nemmeno protegge. Se manca questo requisito, un avviso automatico te lo segnala subito dopo aver premuto il pulsante.

QUINDI, PER SICUREZZA: SE NON SEI SICURO DI AVER AVVIATO MANAGERSHOW COME AMMINISTRATORE, VAI SEMPRE A CONTROLLARE E BLOCCARE GLI AGGIORNAMENTI DI WINDOWS A MANO (Impostazioni > Windows Update > Sospendi aggiornamenti), ALMENO 2-3 ORE PRIMA DELL'ORARIO DI ACCENSIONE DELLO SHOW, COSI' NON AUMENTA IL RISCHIO DI CRASH DI LOR E DEL RESTO DEL SISTEMA DURANTE LA SERATA.""",
    },
    "en": {
        "titolo": "Guide - Automatic cleanup",
        "corpo": """CLEANUP IS AUTOMATIC, NOT MANUAL

This box configures what happens by itself every day, a number of minutes BEFORE Start time - you don't need to press anything each time. Once you've pressed "Schedule Win Auto" in the Schedule Status box, Windows runs the cleanup on its own, every scheduled day, without you having to remember it.

The "Clean now" button is NOT the automatic one: it's only for testing the cleanup right away, or running it on demand at any moment - it must be pressed by hand, it never starts on its own based on time/days.

WHAT IT CLEANS
- Closes Chrome, if the "Close Chrome" box is checked (frees RAM).
- Clears Windows temp files and ONLY Chrome's cache, if "Clear temp files and Chrome cache" is checked (never passwords/bookmarks/history).
- Also closes the "Programs to close automatically" you add with the "Add..." button: it opens a file search to pick the exact program (even on another drive), no need to type anything by hand.

CONFIRMATION BEFORE CLOSING
Before closing Chrome or any program on the list, a Yes/No confirmation popup always appears, so nothing closes unexpectedly if someone is using it. The popup has a 20-second countdown: if nobody answers (e.g. an overnight cleanup with nobody at the PC), by default it does NOT close it - it won't block cleanup forever, but it won't force a close without permission either.

WINDOWS UPDATES - IMPORTANT
The "Block Windows updates" checkbox tries to stop Windows Update automatically every time cleanup runs, so a surprise reboot or install doesn't happen while the show is on. For this to actually work, the 3 scheduled tasks need to be created with the highest privileges available - and THIS REQUIRES MANAGERSHOW.PYW TO ALREADY BE RUNNING WITH "RUN AS ADMINISTRATOR" AT THE EXACT MOMENT YOU PRESS "SCHEDULE WIN AUTO" (ManagerShow now tries to relaunch itself elevated on every startup, asking for confirmation via the Windows prompt). Being an administrator account isn't enough: if ManagerShow isn't elevated right then, Windows denies creating the tasks with those privileges ("Access denied" error), so the tasks still get created but with normal permissions, and the automatic block simply won't do anything - it won't break the scheduling, but it won't protect you either. If this requirement is missing, an automatic warning tells you right after you press the button.

SO, TO BE SAFE: IF YOU'RE NOT SURE YOU STARTED MANAGERSHOW AS ADMINISTRATOR, ALWAYS GO AND BLOCK WINDOWS UPDATES BY HAND (Settings > Windows Update > Pause updates), AT LEAST 2-3 HOURS BEFORE THE SHOW'S START TIME, SO THE RISK OF LOR AND THE REST OF THE SYSTEM CRASHING DURING THE EVENING DOESN'T GO UP.""",
    },
}


class FinestraGuida(tk.Toplevel):
    def __init__(self, padre, lingua: str):
        super().__init__(padre)
        self.title(TESTO_GUIDA[lingua]["titolo"])
        self.geometry("480x640")
        self.transient(padre)

        testo_widget = tk.Text(self, wrap="word", padx=12, pady=12, font=("Segoe UI", 10))
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=testo_widget.yview)
        testo_widget.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        testo_widget.pack(side="left", fill="both", expand=True)

        testo_widget.insert("1.0", TESTO_GUIDA[lingua]["corpo"])
        testo_widget.configure(state="disabled")


# ----------------------------------------------------------------------
# Finestra principale
# ----------------------------------------------------------------------
class ManagerShow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.lingua = leggi_lingua_iniziale()
        self.geometry("820x580+340+130")
        self.finestra_guida = None
        self.finestra_guida_pulizia = None
        self.bind("<Configure>", self._al_muovere_finestra)

        barra_superiore = ttk.Frame(self)
        barra_superiore.pack(fill="x", padx=8, pady=(8, 0))
        # tk.Button invece di ttk.Button: su Windows il tema nativo ("vista")
        # ignora bg/fg sui pulsanti ttk, con tk.Button il colore si vede sempre
        self.bottone_lingua = tk.Button(
            barra_superiore, command=self._cambia_lingua, width=4,
            bg="#1565c0", fg="white", activebackground="#0d47a1", activeforeground="white",
            relief="raised", cursor="hand2",
        )
        self.bottone_lingua.pack(side="right")

        # Schede Luci (2026-07-24): tool separato per l'inventario tecnico
        # schede/canali/alimentazione, vive fuori da questa cartella in
        # 04_SCHEDE_LUCI - qui solo un lancio, nessuno stato condiviso.
        ttk.Button(barra_superiore, text="SCHEDE LUCI", command=apri_schede_luci).pack(side="left")

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

        self.tab_canzoni = ttk.Frame(self.notebook)
        self.tab_programmazione = ttk.Frame(self.notebook)
        self.notebook.add(self.tab_canzoni, text="Canzoni")
        self.notebook.add(self.tab_programmazione, text="Programmazione")

        self._costruisci_tab_canzoni(self.tab_canzoni)
        self._costruisci_tab_programmazione(self.tab_programmazione)

        self._ritraduci_interfaccia()
        self.ricarica_lista()
        self._aggiorna_stato_pianificazione()
        self._aggiorna_stato_processi()

    def _t(self, chiave: str, **valori) -> str:
        return testo(self.lingua, chiave, **valori)

    # ------------------------------------------------------------------
    # Scheda Canzoni
    # ------------------------------------------------------------------
    def _costruisci_tab_canzoni(self, padre):
        colonne = ("numero", "titolo", "artista", "durata", "trigger", "nome_lor", "stato")
        self.albero = ttk.Treeview(padre, columns=colonne, show="headings", selectmode="browse")
        for colonna, larghezza in (
            ("numero", 36), ("titolo", 220), ("artista", 160), ("durata", 70), ("trigger", 130), ("nome_lor", 180), ("stato", 110),
        ):
            self.albero.column(colonna, width=larghezza, stretch=(colonna != "numero"), anchor="center" if colonna == "numero" else "w")
        self.albero.pack(fill="both", expand=True, padx=8, pady=8)
        self.albero.bind("<Double-1>", lambda evento: self._modifica())

        frame_bottoni_1 = ttk.Frame(padre)
        frame_bottoni_1.pack(fill="x", padx=8, pady=(0, 4))
        frame_bottoni_2 = ttk.Frame(padre)
        frame_bottoni_2.pack(fill="x", padx=8, pady=(0, 8))

        self.bottone_aggiorna = ttk.Button(frame_bottoni_1, command=self.ricarica_lista)
        self.bottone_aggiorna.pack(side="left", padx=4)
        self.bottone_aggiungi = ttk.Button(frame_bottoni_1, command=self._aggiungi)
        self.bottone_aggiungi.pack(side="left", padx=4)
        self.bottone_modifica = ttk.Button(frame_bottoni_1, command=self._modifica)
        self.bottone_modifica.pack(side="left", padx=4)
        self.bottone_escludi = ttk.Button(frame_bottoni_1, command=self._alterna_esclusione)
        self.bottone_escludi.pack(side="left", padx=4)

        self.bottone_apri_voto = ttk.Button(frame_bottoni_2, command=self._apri_pagina_voto)
        self.bottone_apri_voto.pack(side="left", padx=4)
        self.bottone_apri_risultati = ttk.Button(frame_bottoni_2, command=self._apri_risultati)
        self.bottone_apri_risultati.pack(side="left", padx=4)
        self.bottone_rigenera = ttk.Button(frame_bottoni_2, command=self._rigenera_manuale)
        self.bottone_rigenera.pack(side="left", padx=4)

    def _cambia_lingua(self):
        self.lingua = "en" if self.lingua == "it" else "it"
        self._ritraduci_interfaccia()
        self.ricarica_lista()

    def _ritraduci_interfaccia(self):
        self.title(self._t("ms_titolo_finestra"))
        self.notebook.tab(self.tab_canzoni, text=self._t("ms_scheda_canzoni"))
        self.notebook.tab(self.tab_programmazione, text=self._t("ms_scheda_programmazione"))
        self.bottone_lingua.configure(text=self._t("gc_lingua_bottone"))

        self.albero.heading("numero", text=self._t("gc_colonna_numero"))
        self.albero.heading("titolo", text=self._t("gc_colonna_titolo"))
        self.albero.heading("artista", text=self._t("gc_colonna_artista"))
        self.albero.heading("durata", text=self._t("gc_colonna_durata"))
        self.albero.heading("trigger", text=self._t("gc_colonna_trigger"))
        self.albero.heading("nome_lor", text=self._t("gc_colonna_nome_lor"))
        self.albero.heading("stato", text=self._t("gc_colonna_stato"))

        self.bottone_aggiorna.configure(text=self._t("gc_bottone_aggiorna_lista"))
        self.bottone_aggiungi.configure(text=self._t("gc_bottone_aggiungi"))
        self.bottone_modifica.configure(text=self._t("gc_bottone_modifica"))
        self.bottone_escludi.configure(text=self._t("gc_bottone_escludi_includi"))
        self.bottone_apri_voto.configure(text=self._t("gc_bottone_apri_voto"))
        self.bottone_apri_risultati.configure(text=self._t("gc_bottone_apri_risultati"))
        self.bottone_rigenera.configure(text=self._t("gc_bottone_rigenera"))

        self.frame_stato_live.configure(text=self._t("ms_titolo_stato_attuale"))
        self.frame_orari.configure(text=self._t("ms_titolo_orari"))
        self.label_accensione.configure(text=self._t("ms_campo_accensione"))
        self.label_spegnimento.configure(text=self._t("ms_campo_spegnimento"))
        self.label_giorni.configure(text=self._t("ms_titolo_giorni"))
        for indice, checkbutton in enumerate(self.checkbutton_giorni):
            checkbutton.configure(text=self._t(f"ms_giorno_{indice}"))
        self.frame_pulizia.configure(text=self._t("ms_titolo_pulizia"))
        self.label_minuti_anticipo.configure(text=self._t("ms_campo_minuti_anticipo"))
        self.bottone_pulisci_ora.configure(text=self._t("ms_bottone_pulisci_ora"))
        self.bottone_guida_pulizia.configure(text=self._t("ms_bottone_guida_pulizia"))
        self.checkbutton_chiudi_chrome.configure(text=self._t("ms_titolo_chiudi_chrome"))
        self.checkbutton_pulisci_cache.configure(text=self._t("ms_titolo_pulisci_cache"))
        self.checkbutton_blocca_aggiornamenti.configure(text=self._t("ms_titolo_blocca_aggiornamenti"))
        self.label_programmi_extra.configure(text=self._t("ms_label_programmi_extra"))
        self.bottone_aggiungi_programma.configure(text=self._t("ms_bottone_apri_gestione_programmi"))
        self.bottone_salva_orari.configure(text=self._t("ms_bottone_salva_orari"))


        self.bottone_guida.configure(text=self._t("ms_bottone_guida"))
        self.label_avviso_avvia_ferma.configure(text=self._t("ms_avviso_avvia_ferma_testo"))
        if self.finestra_guida is not None and self.finestra_guida.winfo_exists():
            self.finestra_guida.destroy()
            self.finestra_guida = None
        if self.finestra_guida_pulizia is not None and self.finestra_guida_pulizia.winfo_exists():
            self.finestra_guida_pulizia.destroy()
            self.finestra_guida_pulizia = None

        self._aggiorna_stato_pianificazione()

    # ------------------------------------------------------------------
    # Finestra Guida: agganciata alla GUI principale, si riposiziona
    # sempre di fianco (segue lo spostamento, e riappare vicina anche
    # se era stata chiusa e la finestra principale spostata nel frattempo).
    # ------------------------------------------------------------------
    def _al_muovere_finestra(self, evento):
        if evento.widget is not self:
            return
        self._posiziona_guida_se_aperta()
        self._posiziona_guida_pulizia_se_aperta()

    def _posiziona_guida_se_aperta(self):
        if self.finestra_guida is None or not self.finestra_guida.winfo_exists():
            return
        x, y = self._calcola_posizione_guida()
        self.finestra_guida.geometry(f"+{x}+{y}")

    def _calcola_posizione_guida(self):
        self.update_idletasks()
        x_principale = self.winfo_x()
        y_principale = self.winfo_y()
        larghezza_principale = self.winfo_width()
        larghezza_guida = self.finestra_guida.winfo_width() if self.finestra_guida is not None else 480
        schermo_larghezza = self.winfo_screenwidth()

        x = x_principale + larghezza_principale + 8
        if x + larghezza_guida > schermo_larghezza:
            x = max(x_principale - larghezza_guida - 8, 0)
        return x, y_principale

    def _apri_guida(self):
        if self.finestra_guida is not None and self.finestra_guida.winfo_exists():
            self.finestra_guida.lift()
            self.finestra_guida.focus_set()
            return

        self.finestra_guida = FinestraGuida(self, self.lingua)
        self.finestra_guida.protocol("WM_DELETE_WINDOW", self._chiudi_guida)
        self.finestra_guida.update_idletasks()
        x, y = self._calcola_posizione_guida()
        self.finestra_guida.geometry(f"+{x}+{y}")

    def _chiudi_guida(self):
        if self.finestra_guida is not None:
            self.finestra_guida.destroy()
        self.finestra_guida = None

    # ------------------------------------------------------------------
    # Finestra Guida Pulizia: stesso principio della Guida principale, ma
    # agganciata SOTTO ManagerShow, allineata all'angolo sinistro e larga
    # quanto ManagerShow (angolo destro coincidente).
    # ------------------------------------------------------------------
    def _posiziona_guida_pulizia_se_aperta(self):
        if self.finestra_guida_pulizia is None or not self.finestra_guida_pulizia.winfo_exists():
            return
        x, y, larghezza, altezza = self._calcola_posizione_guida_pulizia()
        self.finestra_guida_pulizia.geometry(f"{larghezza}x{altezza}+{x}+{y}")

    @staticmethod
    def _area_lavoro_basso() -> int:
        """Bordo inferiore vero dello schermo, ESCLUSA la barra delle
        applicazioni di Windows (winfo_screenheight() include invece
        anche la barra, facendo credere che ci sia piu' spazio libero di
        quanto ce ne sia davvero)."""
        try:
            rect = ctypes.wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(rect), 0)  # SPI_GETWORKAREA
            return rect.bottom
        except (OSError, AttributeError):
            return 0

    def _rettangolo_finestra_vero(self) -> tuple:
        """Rettangolo VERO di ManagerShow (bordi e barra del titolo
        compresi), quello che corrisponde esattamente a cosa si vede a
        video e a cosa controlla geometry(). winfo_id() di Tkinter
        ritorna l'handle della sola area contenuto, non della finestra
        di primo livello: GetWindowRect chiamato direttamente su quello
        da' un rettangolo piu' piccolo (senza titolo ne' bordi), sfalsato
        rispetto alla finestra vera. GetAncestor(..., GA_ROOT) risale
        prima alla vera finestra di primo livello - verificato dal vivo
        che cosi' il rettangolo coincide esattamente con la geometria
        richiesta."""
        try:
            GA_ROOT = 2
            hwnd_root = ctypes.windll.user32.GetAncestor(
                ctypes.wintypes.HWND(self.winfo_id()), GA_ROOT
            )
            rect = ctypes.wintypes.RECT()
            ctypes.windll.user32.GetWindowRect(ctypes.wintypes.HWND(hwnd_root), ctypes.byref(rect))
            if rect.right > rect.left and rect.bottom > rect.top:
                return rect.left, rect.top, rect.right, rect.bottom
        except (OSError, AttributeError):
            pass
        return self.winfo_x(), self.winfo_y(), self.winfo_x() + self.winfo_width(), self.winfo_y() + self.winfo_height()

    def _calcola_posizione_guida_pulizia(self):
        self.update_idletasks()
        sinistra, _, destra, basso = self._rettangolo_finestra_vero()
        x = sinistra
        # destra-sinistra e' la larghezza VERA (bordi compresi) di
        # ManagerShow, ma geometry() sulla guida imposta solo l'area
        # contenuto: senza correzione la guida risulterebbe piu' larga di
        # ManagerShow del bordo della finestra stessa (~16px su Windows).
        larghezza = (destra - sinistra) - 16

        area_basso = self._area_lavoro_basso() or self.winfo_screenheight()
        y = basso + 8
        altezza_desiderata = 380

        # La guida non deve MAI partire piu' in alto del bordo inferiore
        # VERO di ManagerShow (altrimenti Windows la ripiazzerebbe
        # sovrapposta per farla entrare a schermo): se sotto non c'e'
        # spazio per l'altezza desiderata, si riduce l'altezza, mai la
        # posizione. Margine di sicurezza abbondante (48px, non 8) sopra
        # alla barra applicazioni, cosi' bordo/pulsanti della finestra
        # restano visibili anche se il calcolo dell'area di lavoro non
        # fosse preciso al pixel su questo monitor.
        altezza = min(altezza_desiderata, max(area_basso - y - 48, 120))

        return x, y, larghezza, altezza

    def _apri_guida_pulizia(self):
        if self.finestra_guida_pulizia is not None and self.finestra_guida_pulizia.winfo_exists():
            self.finestra_guida_pulizia.lift()
            self.finestra_guida_pulizia.focus_set()
            return

        finestra = tk.Toplevel(self)
        finestra.title(TESTO_GUIDA_PULIZIA[self.lingua]["titolo"])
        finestra.transient(self)

        testo_widget = tk.Text(finestra, wrap="word", padx=12, pady=12, font=("Segoe UI", 10))
        scrollbar = ttk.Scrollbar(finestra, orient="vertical", command=testo_widget.yview)
        testo_widget.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        testo_widget.pack(side="left", fill="both", expand=True)
        testo_widget.insert("1.0", TESTO_GUIDA_PULIZIA[self.lingua]["corpo"])
        testo_widget.configure(state="disabled")

        self.finestra_guida_pulizia = finestra
        self.finestra_guida_pulizia.protocol("WM_DELETE_WINDOW", self._chiudi_guida_pulizia)
        x, y, larghezza, altezza = self._calcola_posizione_guida_pulizia()
        self.finestra_guida_pulizia.geometry(f"{larghezza}x{altezza}+{x}+{y}")

    def _chiudi_guida_pulizia(self):
        if self.finestra_guida_pulizia is not None:
            self.finestra_guida_pulizia.destroy()
        self.finestra_guida_pulizia = None

    def _apri_pagina_voto(self):
        parser = carica_parser()
        porta = parser.getint(SEZIONE_VOTO, "Porta_Server", fallback=8080)
        webbrowser.open(f"http://localhost:{porta}/")

    def _apri_risultati(self):
        parser = carica_parser()
        porta = parser.getint(SEZIONE_VOTO, "Porta_Server", fallback=8080)
        token = parser.get(SEZIONE_VOTO, "Token_Amministratore", fallback="").strip()
        url = f"http://localhost:{porta}/risultati"
        if token:
            url += f"?token={token}"
        webbrowser.open(url)

    def ricarica_lista(self):
        for riga in self.albero.get_children():
            self.albero.delete(riga)

        parser = carica_parser()
        cartella_sequenze = leggi_cartella_sequenze(parser)
        cartelle_escluse = {c.lower() for c in leggi_cartelle_escluse(parser)}

        if not cartella_sequenze.is_dir():
            messagebox.showerror(
                self._t("gc_cartella_non_trovata_titolo"),
                self._t("gc_cartella_non_trovata_testo", percorso=cartella_sequenze),
            )
            return

        self._cache_anteprime = {}
        prossimo_numero = 1
        for cartella in sorted(p for p in cartella_sequenze.iterdir() if p.is_dir()):
            if cartella.name.strip().lower() == "01 intro":
                numero = 0
            else:
                numero = prossimo_numero
                prossimo_numero += 1
            info = anteprima_sequenza(cartella)
            self._cache_anteprime[cartella.name] = info

            esclusa = cartella.name.lower() in cartelle_escluse
            if not info["ha_audio"]:
                stato = self._t("gc_stato_senza_audio")
            elif esclusa:
                stato = self._t("gc_stato_esclusa")
            else:
                stato = self._t("gc_stato_votabile")

            trigger = leggi_trigger(parser, info["id"])
            nome_lor = leggi_nome_lor(parser, info["id"])
            self.albero.insert(
                "", "end", iid=cartella.name,
                values=(numero, info["titolo"], info["artista"], info["durata_testo"], trigger, nome_lor, stato),
            )

    def _cartella_selezionata(self) -> str:
        selezione = self.albero.selection()
        if not selezione:
            messagebox.showinfo(self._t("gc_nessuna_selezione_titolo"), self._t("gc_nessuna_selezione_testo"))
            return None
        return selezione[0]

    def _aggiungi(self):
        parser = carica_parser()
        cartella_sequenze = leggi_cartella_sequenze(parser)
        dialogo = DialogoCanzone(self, cartella_sequenze, self.lingua)
        self.wait_window(dialogo)
        if dialogo.risultato_salvato:
            self.ricarica_lista()

    def _modifica(self):
        nome_cartella = self._cartella_selezionata()
        if nome_cartella is None:
            return
        info = self._cache_anteprime.get(nome_cartella)
        if info is None or not info["ha_audio"]:
            messagebox.showwarning(self._t("gc_non_modificabile_titolo"), self._t("gc_non_modificabile_testo"))
            return

        parser = carica_parser()
        cartella_sequenze = leggi_cartella_sequenze(parser)
        dialogo = DialogoCanzone(self, cartella_sequenze, self.lingua, dati_esistenti=info)
        self.wait_window(dialogo)
        if dialogo.risultato_salvato:
            self.ricarica_lista()

    def _alterna_esclusione(self):
        nome_cartella = self._cartella_selezionata()
        if nome_cartella is None:
            return

        parser = carica_parser()
        cartelle_escluse = leggi_cartelle_escluse(parser)
        cartelle_escluse_lower = {c.lower() for c in cartelle_escluse}

        if nome_cartella.lower() in cartelle_escluse_lower:
            cartelle_escluse = {c for c in cartelle_escluse if c.lower() != nome_cartella.lower()}
            azione = self._t("gc_azione_inclusa")
        else:
            if not messagebox.askyesno(
                self._t("gc_conferma_esclusione_titolo"),
                self._t("gc_conferma_esclusione_testo", nome=nome_cartella),
            ):
                return
            cartelle_escluse.add(nome_cartella)
            azione = self._t("gc_azione_esclusa")

        scrivi_cartelle_escluse(parser, cartelle_escluse)
        salva_parser(parser)

        ok, errore = rigenera_catalogo_sicuro(self.lingua)
        if not ok:
            messagebox.showwarning(
                self._t("gc_attenzione_titolo"),
                self._t("gc_attenzione_testo", nome=nome_cartella, azione=azione, errore=errore),
            )

        self.ricarica_lista()

    def _rigenera_manuale(self):
        ok, errore = rigenera_catalogo_sicuro(self.lingua)
        if ok:
            messagebox.showinfo(self._t("gc_fatto_titolo"), self._t("gc_fatto_testo"))
        else:
            messagebox.showerror(self._t("gc_errore_titolo"), self._t("gc_rigenerazione_fallita", errore=errore))
        self.ricarica_lista()

    # ------------------------------------------------------------------
    # Scheda Programmazione
    # ------------------------------------------------------------------
    def _costruisci_tab_programmazione(self, padre):
        padding = {"padx": 8, "pady": 4}
        padre.columnconfigure(0, weight=1)

        frame_guida_bottone = ttk.Frame(padre)
        frame_guida_bottone.grid(row=0, column=1, sticky="ne", padx=8, pady=4)
        self.bottone_guida = ttk.Button(frame_guida_bottone, command=self._apri_guida)
        self.bottone_guida.pack()

        self.frame_stato_live = ttk.LabelFrame(padre)
        self.frame_stato_live.grid(row=0, column=0, sticky="ew", **padding)

        # Un frame per riga con pack (non grid condiviso con altre righe):
        # cosi' pallino e testo restano sempre incollati, senza che la
        # larghezza di colonna venga influenzata da nient'altro nel box.
        riga_voto = ttk.Frame(self.frame_stato_live)
        riga_voto.grid(row=0, column=0, columnspan=3, sticky="w", padx=8, pady=6)
        self.pallino_voto = tk.Label(riga_voto, text="  ", bg="#c62828", width=1)
        self.pallino_voto.pack(side="left")
        self.var_stato_voto = tk.StringVar(value="VotoShow.py: ...")
        tk.Label(riga_voto, textvariable=self.var_stato_voto, padx=0).pack(side="left", padx=(4, 0))

        riga_motore = ttk.Frame(self.frame_stato_live)
        riga_motore.grid(row=1, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 6))
        self.pallino_motore = tk.Label(riga_motore, text="  ", bg="#9e9e9e", width=1)
        self.pallino_motore.pack(side="left")
        self.var_stato_motore = tk.StringVar(value="MotoreShow.py: ...")
        tk.Label(riga_motore, textvariable=self.var_stato_motore, padx=0).pack(side="left", padx=(4, 0))

        frame_bottoni_stato_live = ttk.Frame(self.frame_stato_live)
        frame_bottoni_stato_live.grid(row=2, column=0, columnspan=3, sticky="w", padx=8, pady=(2, 4))
        self.bottone_avvia_ferma = ttk.Button(frame_bottoni_stato_live, command=self._alterna_avvio_ferma)
        self.bottone_avvia_ferma.pack(side="left")

        self.label_avviso_avvia_ferma = ttk.Label(
            self.frame_stato_live, foreground="#888", justify="left", wraplength=520,
        )
        self.label_avviso_avvia_ferma.grid(row=3, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 8))

        self.frame_orari = ttk.LabelFrame(padre)
        self.frame_orari.grid(row=1, column=0, sticky="ew", **padding)

        self.label_accensione = ttk.Label(self.frame_orari)
        self.label_accensione.grid(row=0, column=0, sticky="w", **padding)
        self.var_accensione = tk.StringVar()
        ttk.Entry(self.frame_orari, textvariable=self.var_accensione, width=10).grid(row=0, column=1, sticky="w", **padding)

        self.label_spegnimento = ttk.Label(self.frame_orari)
        self.label_spegnimento.grid(row=1, column=0, sticky="w", **padding)
        self.var_spegnimento = tk.StringVar()
        ttk.Entry(self.frame_orari, textvariable=self.var_spegnimento, width=10).grid(row=1, column=1, sticky="w", **padding)

        self.label_giorni = ttk.Label(self.frame_orari)
        self.label_giorni.grid(row=2, column=0, columnspan=4, sticky="w", padx=8, pady=(6, 0))
        frame_checkbox_giorni = ttk.Frame(self.frame_orari)
        frame_checkbox_giorni.grid(row=3, column=0, columnspan=4, sticky="w", padx=8, pady=(2, 4))
        self.var_giorni = [tk.BooleanVar() for _ in GIORNI_SETTIMANA]
        self.checkbutton_giorni = []
        for indice in range(len(GIORNI_SETTIMANA)):
            checkbutton = ttk.Checkbutton(frame_checkbox_giorni, variable=self.var_giorni[indice])
            checkbutton.grid(row=0, column=indice, padx=4)
            self.checkbutton_giorni.append(checkbutton)

        frame_bottoni_orari = ttk.Frame(self.frame_orari)
        frame_bottoni_orari.grid(row=4, column=0, columnspan=4, sticky="w", padx=8, pady=(4, 8))
        self.bottone_salva_orari = ttk.Button(frame_bottoni_orari, command=self._salva_orari_bottone)
        self.bottone_salva_orari.pack(side="left", padx=(0, 4))
        self.bottone_pianificazione = ttk.Button(frame_bottoni_orari, command=self._alterna_pianificazione)
        self.bottone_pianificazione.pack(side="left", padx=4)

        self.var_stato_pianificazione = tk.StringVar(value="...")
        self.label_stato_pianificazione = ttk.Label(
            frame_bottoni_orari, textvariable=self.var_stato_pianificazione, justify="left", wraplength=340,
        )
        self.label_stato_pianificazione.pack(side="left", padx=(8, 0))

        self.frame_pulizia = ttk.LabelFrame(padre)
        self.frame_pulizia.grid(row=2, column=0, sticky="ew", **padding)
        self.label_minuti_anticipo = ttk.Label(self.frame_pulizia)
        self.label_minuti_anticipo.grid(row=0, column=0, sticky="w", **padding)
        self.var_minuti_anticipo = tk.StringVar()
        ttk.Entry(self.frame_pulizia, textvariable=self.var_minuti_anticipo, width=6).grid(
            row=0, column=1, sticky="w", padx=(4, 4), pady=4
        )
        self.bottone_pulisci_ora = ttk.Button(self.frame_pulizia, command=self._pulisci_ora)
        self.bottone_pulisci_ora.grid(row=0, column=2, padx=(0, 4))
        self.bottone_guida_pulizia = ttk.Button(self.frame_pulizia, command=self._apri_guida_pulizia)
        self.bottone_guida_pulizia.grid(row=0, column=3, padx=(0, 8))

        self.var_chiudi_chrome = tk.BooleanVar()
        self.checkbutton_chiudi_chrome = ttk.Checkbutton(self.frame_pulizia, variable=self.var_chiudi_chrome)
        self.checkbutton_chiudi_chrome.grid(row=1, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 2))

        self.var_pulisci_cache = tk.BooleanVar()
        self.checkbutton_pulisci_cache = ttk.Checkbutton(self.frame_pulizia, variable=self.var_pulisci_cache)
        self.checkbutton_pulisci_cache.grid(row=2, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 2))

        self.var_blocca_aggiornamenti = tk.BooleanVar()
        self.checkbutton_blocca_aggiornamenti = ttk.Checkbutton(
            self.frame_pulizia, variable=self.var_blocca_aggiornamenti,
        )
        self.checkbutton_blocca_aggiornamenti.grid(row=3, column=0, columnspan=3, sticky="w", padx=8, pady=(0, 4))

        self.programmi_extra = []
        frame_programmi_extra_label = ttk.Frame(self.frame_pulizia)
        frame_programmi_extra_label.grid(row=4, column=0, columnspan=4, sticky="w", padx=8, pady=(4, 0))
        self.label_programmi_extra = ttk.Label(frame_programmi_extra_label)
        self.label_programmi_extra.pack(side="left")
        self.bottone_aggiungi_programma = ttk.Button(
            frame_programmi_extra_label, command=self._apri_gestione_programmi_extra,
        )
        self.bottone_aggiungi_programma.pack(side="left", padx=(4, 0))

        self.var_programmi_extra_testo = tk.StringVar(value="-")
        ttk.Label(
            self.frame_pulizia, textvariable=self.var_programmi_extra_testo, foreground="#888", wraplength=460,
        ).grid(row=5, column=0, columnspan=4, sticky="w", padx=8, pady=(0, 8))

        self._carica_orari_da_ini()

    def _carica_orari_da_ini(self):
        parser = carica_parser()
        orari = parser[SEZIONE_ORARI]
        self.var_accensione.set(orari.get("Orario_Accensione", "17:30"))
        self.var_spegnimento.set(orari.get("Orario_Spegnimento", "22:30"))

        giorni_raw = orari.get("Giorni_Attivi", "0,1,2,3,4,5,6")
        giorni_salvati = {g.strip() for g in giorni_raw.split(",") if g.strip()}
        for indice in range(len(GIORNI_SETTIMANA)):
            self.var_giorni[indice].set(str(indice) in giorni_salvati)

        pulizia = parser[SEZIONE_PULIZIA] if SEZIONE_PULIZIA in parser else {}
        self.var_minuti_anticipo.set(str(pulizia.get("Minuti_Anticipo", "15")))
        self.var_chiudi_chrome.set(
            SEZIONE_PULIZIA not in parser or parser.getboolean(SEZIONE_PULIZIA, "Chiudi_Chrome", fallback=True)
        )
        self.var_pulisci_cache.set(
            SEZIONE_PULIZIA not in parser or parser.getboolean(SEZIONE_PULIZIA, "Pulisci_File_Temporanei", fallback=True)
        )
        self.var_blocca_aggiornamenti.set(
            SEZIONE_PULIZIA in parser and parser.getboolean(SEZIONE_PULIZIA, "Blocca_Aggiornamenti_Windows", fallback=False)
        )
        grezzo_programmi = pulizia.get("Programmi_Extra", "").strip() if pulizia else ""
        self.programmi_extra = [p.strip() for p in grezzo_programmi.split(",") if p.strip()]
        self._aggiorna_etichetta_programmi_extra()

    def _aggiorna_etichetta_programmi_extra(self):
        self.var_programmi_extra_testo.set(", ".join(self.programmi_extra) if self.programmi_extra else "-")

    @staticmethod
    def _orario_valido(testo_orario: str) -> bool:
        try:
            datetime.strptime(testo_orario.strip(), "%H:%M")
            return True
        except ValueError:
            return False

    def _valida_orari(self) -> bool:
        if not self._orario_valido(self.var_accensione.get()):
            messagebox.showerror(self._t("ms_errore_orario_titolo"), self._t("ms_errore_orario_accensione_testo"))
            return False
        if not self._orario_valido(self.var_spegnimento.get()):
            messagebox.showerror(self._t("ms_errore_orario_titolo"), self._t("ms_errore_orario_spegnimento_testo"))
            return False
        if not any(v.get() for v in self.var_giorni):
            messagebox.showerror(self._t("ms_errore_nessun_giorno_titolo"), self._t("ms_errore_nessun_giorno_testo"))
            return False
        if not self.var_minuti_anticipo.get().strip().isdigit():
            messagebox.showerror(self._t("ms_errore_minuti_titolo"), self._t("ms_errore_minuti_testo"))
            return False
        return True

    def _salva_orari_su_ini(self) -> bool:
        if not self._valida_orari():
            return False
        parser = carica_parser()
        parser[SEZIONE_ORARI]["Orario_Accensione"] = self.var_accensione.get().strip()
        parser[SEZIONE_ORARI]["Orario_Spegnimento"] = self.var_spegnimento.get().strip()
        giorni_selezionati = [str(i) for i, v in enumerate(self.var_giorni) if v.get()]
        parser[SEZIONE_ORARI]["Giorni_Attivi"] = ",".join(giorni_selezionati)
        if SEZIONE_PULIZIA not in parser:
            parser[SEZIONE_PULIZIA] = {}
        parser[SEZIONE_PULIZIA]["Minuti_Anticipo"] = self.var_minuti_anticipo.get().strip()
        parser[SEZIONE_PULIZIA]["Chiudi_Chrome"] = str(self.var_chiudi_chrome.get())
        parser[SEZIONE_PULIZIA]["Pulisci_File_Temporanei"] = str(self.var_pulisci_cache.get())
        parser[SEZIONE_PULIZIA]["Blocca_Aggiornamenti_Windows"] = str(self.var_blocca_aggiornamenti.get())
        parser[SEZIONE_PULIZIA]["Programmi_Extra"] = ", ".join(self.programmi_extra)
        salva_parser(parser)
        return True

    def _salva_orari_bottone(self):
        if self._salva_orari_su_ini():
            messagebox.showinfo(self._t("gc_fatto_titolo"), self._t("ms_salva_orari_promemoria_testo"))

    def _applica_pianificazione(self):
        if not self._salva_orari_su_ini():
            return

        giorni_indici = [i for i, v in enumerate(self.var_giorni) if v.get()]
        giorni_schtasks = [MAPPA_GIORNI_SCHTASKS[i] for i in giorni_indici]
        orario_pulizia = _calcola_orario_anticipato(
            self.var_accensione.get().strip(), int(self.var_minuti_anticipo.get().strip())
        )

        ok_avvio, errore_avvio = _crea_task(
            NOME_TASK_AVVIO, CARTELLA_AUTOMAZIONE / "AvviaShow.py", giorni_schtasks, self.var_accensione.get().strip()
        )
        ok_stop, errore_stop = _crea_task(
            NOME_TASK_STOP, CARTELLA_AUTOMAZIONE / "FermaShow.py", giorni_schtasks, self.var_spegnimento.get().strip()
        )
        ok_pulizia, errore_pulizia = _crea_task(
            NOME_TASK_PULIZIA, CARTELLA_AUTOMAZIONE / "PuliziaPreShow.py", giorni_schtasks, orario_pulizia
        )

        if ok_avvio and ok_stop and ok_pulizia:
            messagebox.showinfo(
                self._t("gc_fatto_titolo"),
                self._t("ms_pianificazione_applicata_testo", orario=orario_pulizia),
            )
            if self.var_blocca_aggiornamenti.get() and not _processo_e_elevato():
                messagebox.showwarning(
                    self._t("ms_avviso_no_admin_titolo"),
                    self._t("ms_avviso_no_admin_testo"),
                )
        else:
            dettagli = []
            if not ok_avvio:
                dettagli.append(f"{self._t('ms_prefisso_avvio')}: {errore_avvio}")
            if not ok_stop:
                dettagli.append(f"{self._t('ms_prefisso_stop')}: {errore_stop}")
            if not ok_pulizia:
                dettagli.append(f"{self._t('ms_prefisso_pulizia')}: {errore_pulizia}")
            messagebox.showerror(
                self._t("gc_errore_titolo"),
                self._t("ms_pianificazione_fallita_testo", dettagli="\n".join(dettagli)),
            )

        self._aggiorna_stato_pianificazione()

    def _rimuovi_pianificazione(self):
        if not messagebox.askyesno(self._t("ms_conferma_titolo"), self._t("ms_conferma_rimozione_testo")):
            return
        _elimina_task(NOME_TASK_PULIZIA)
        _elimina_task(NOME_TASK_AVVIO)
        _elimina_task(NOME_TASK_STOP)
        messagebox.showinfo(self._t("gc_fatto_titolo"), self._t("ms_pianificazione_rimossa_testo"))
        self._aggiorna_stato_pianificazione()

    def _alterna_pianificazione(self):
        if _task_esiste(NOME_TASK_AVVIO) and _task_esiste(NOME_TASK_STOP) and _task_esiste(NOME_TASK_PULIZIA):
            self._rimuovi_pianificazione()
        else:
            self._applica_pianificazione()

    def _aggiorna_stato_pianificazione(self):
        registrato_avvio = _task_esiste(NOME_TASK_AVVIO)
        registrato_stop = _task_esiste(NOME_TASK_STOP)
        registrato_pulizia = _task_esiste(NOME_TASK_PULIZIA)
        if registrato_avvio and registrato_stop and registrato_pulizia:
            self.var_stato_pianificazione.set(self._t("ms_stato_pianificazione_attiva"))
            self.label_stato_pianificazione.configure(foreground="#2e7d32")
            self.bottone_pianificazione.configure(text=self._t("ms_bottone_rimuovi"))
        else:
            self.var_stato_pianificazione.set(self._t("ms_stato_pianificazione_non_attiva"))
            self.label_stato_pianificazione.configure(foreground="#c62828")
            self.bottone_pianificazione.configure(text=self._t("ms_bottone_applica"))

    def _pulisci_ora(self):
        PuliziaPreShow.esegui_pulizia()
        messagebox.showinfo(self._t("gc_fatto_titolo"), self._t("ms_pulizia_eseguita_testo"))

    def _apri_gestione_programmi_extra(self):
        finestra = tk.Toplevel(self)
        finestra.title(self._t("ms_titolo_programmi_extra"))
        finestra.resizable(False, False)
        finestra.transient(self)
        finestra.grab_set()

        ttk.Label(finestra, text=self._t("ms_istruzioni_programmi_extra"), wraplength=340, justify="left").grid(
            row=0, column=0, columnspan=3, sticky="w", padx=8, pady=(8, 4)
        )

        lista = tk.Listbox(finestra, height=8, width=40)
        lista.grid(row=1, column=0, columnspan=3, sticky="ew", padx=8, pady=4)
        for nome in self.programmi_extra:
            lista.insert("end", nome)

        def _sfoglia():
            cartella_iniziale = os.environ.get("ProgramFiles", "C:/")
            percorso = filedialog.askopenfilename(
                title=self._t("ms_titolo_programmi_extra"),
                initialdir=cartella_iniziale,
                filetypes=[(self._t("ms_filtro_eseguibili"), "*.exe"), (self._t("gc_filtro_tutti"), "*.*")],
            )
            if not percorso:
                return
            nome = Path(percorso).name
            if nome not in lista.get(0, "end"):
                lista.insert("end", nome)

        def _rimuovi():
            selezione = lista.curselection()
            if selezione:
                lista.delete(selezione[0])

        def _salva_e_chiudi():
            self.programmi_extra = list(lista.get(0, "end"))
            self._aggiorna_etichetta_programmi_extra()
            parser = carica_parser()
            if SEZIONE_PULIZIA not in parser:
                parser[SEZIONE_PULIZIA] = {}
            parser[SEZIONE_PULIZIA]["Programmi_Extra"] = ", ".join(self.programmi_extra)
            salva_parser(parser)
            finestra.destroy()

        frame_sfoglia_rimuovi = ttk.Frame(finestra)
        frame_sfoglia_rimuovi.grid(row=2, column=0, columnspan=3, sticky="w", padx=8, pady=4)
        ttk.Button(frame_sfoglia_rimuovi, text=self._t("ms_bottone_sfoglia_programma"), command=_sfoglia).pack(
            side="left", padx=(0, 4)
        )
        ttk.Button(frame_sfoglia_rimuovi, text=self._t("ms_bottone_rimuovi_programma"), command=_rimuovi).pack(
            side="left"
        )

        frame_chiudi = ttk.Frame(finestra)
        frame_chiudi.grid(row=3, column=0, columnspan=3, sticky="e", padx=8, pady=(4, 8))
        ttk.Button(frame_chiudi, text=self._t("gc_bottone_chiudi"), command=finestra.destroy).pack(side="left", padx=4)
        ttk.Button(frame_chiudi, text=self._t("gc_bottone_salva"), command=_salva_e_chiudi).pack(side="left")

        finestra.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - finestra.winfo_width()) // 2
        y = self.winfo_y() + (self.winfo_height() - finestra.winfo_height()) // 2
        finestra.geometry(f"+{x}+{y}")

    def _disegna_pallino(self, pallino: tk.Label, colore: str):
        pallino.configure(bg=colore)

    def _aggiorna_stato_processi(self):
        voto_attivo = AvviaShow.verifica_in_esecuzione(AvviaShow.FILE_PID_VOTO)
        self._disegna_pallino(self.pallino_voto, "#2e7d32" if voto_attivo else "#c62828")
        stato_voto = self._t("ms_stato_in_esecuzione") if voto_attivo else self._t("ms_stato_fermo")
        self.var_stato_voto.set(f"VotoShow.py: {stato_voto}")
        self.bottone_avvia_ferma.configure(
            text=self._t("ms_bottone_ferma_ora") if voto_attivo else self._t("ms_bottone_avvia_ora")
        )

        motore_attivo = AvviaShow.verifica_in_esecuzione(AvviaShow.FILE_PID_MOTORE)
        self._disegna_pallino(self.pallino_motore, "#2e7d32" if motore_attivo else "#9e9e9e")
        stato_motore = self._t("ms_stato_in_esecuzione") if motore_attivo else self._t("ms_stato_motore_concluso")
        self.var_stato_motore.set(f"MotoreShow.py: {stato_motore}")

        self.after(5000, self._aggiorna_stato_processi)

    def _alterna_avvio_ferma(self):
        if AvviaShow.verifica_in_esecuzione(AvviaShow.FILE_PID_VOTO):
            self._ferma_ora()
        else:
            self._avvia_ora()

    def _avvia_ora(self):
        AvviaShow.avvia(AvviaShow.FILE_VOTOSHOW, AvviaShow.FILE_PID_VOTO)
        AvviaShow.avvia(AvviaShow.FILE_MOTORESHOW, AvviaShow.FILE_PID_MOTORE)
        messagebox.showinfo(self._t("gc_fatto_titolo"), self._t("ms_avviati_testo"))
        self._aggiorna_stato_processi()

    def _ferma_ora(self):
        FermaShow.ferma(FermaShow.FILE_PID_VOTO)
        FermaShow.ferma(FermaShow.FILE_PID_MOTORE)
        messagebox.showinfo(self._t("gc_fatto_titolo"), self._t("ms_fermati_testo"))
        self._aggiorna_stato_processi()


def _rilancia_elevato_se_serve() -> bool:
    """Se ManagerShow non gira gia' con privilegi elevati, prova a
    rilanciarsi da solo con 'Esegui come amministratore' (mostra il
    prompt UAC di Windows) e chiude questa istanza non elevata. Se
    l'utente rifiuta il prompt (o il rilancio fallisce), ritorna False e
    ManagerShow continua comunque, solo senza privilegi elevati - non
    resta mai bloccato fuori dal programma."""
    if _processo_e_elevato():
        return False
    risultato = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, f'"{Path(__file__).resolve()}"', None, 1,
    )
    return risultato > 32


if __name__ == "__main__":
    if _rilancia_elevato_se_serve():
        sys.exit(0)
    app = ManagerShow()
    app.mainloop()
