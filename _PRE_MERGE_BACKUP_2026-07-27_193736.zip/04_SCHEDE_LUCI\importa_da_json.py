"""
importa_da_json.py

Import una tantum dei dati 2025 gia' compilati nel foglio Excel storico
"SCHEDE E CANALI E FIGURE 2025.xltx", gia' estratti in precedenza in
import_excel_2025.json (script Python/openpyxl separato, il layout del foglio
era troppo irregolare per un parser affidabile in un'unica passata - vedi le
chiavi PascalCase nel JSON, eredita' di quella prima estrazione).

Va lanciato una sola volta: `python importa_da_json.py`. Idempotente per
scheda (controllo su tipo+identificativo) quindi si puo' rilanciare in
sicurezza se interrotto a meta'; il memo generale NON e' controllato per
doppioni.
"""

import json
from pathlib import Path

import schede_luci_db as db

JSON_PATH = Path(__file__).parent / "import_excel_2025.json"

MAPPA_HEADER = {
    "Tipo": "tipo",
    "Identificativo": "identificativo",
    "Modello": "modello",
    "Firmware": "firmware",
    "Protocollo": "protocollo",
    "Porta": "porta",
    "ModalitaRete": "modalita_rete",
    "VelocitaKbps": "velocita_kbps",
    "PorteLor": "porte_lor",
    "Enhanced": "enhanced",
    "ColoreCavoRete": "colore_cavo_rete",
    "ColoreEtichettaCavi": "colore_etichetta_cavi",
    "Facciata": "facciata",
    "OrdinePagina": "ordine_pagina",
}

MAPPA_CANALE = {
    "Posizione": "posizione",
    "EtichettaPrefisso": "etichetta_prefisso",
    "NumeroCanale": "numero_canale",
    "Figura": "figura",
    "TipoSpinottiCatena": "tipo_spinotti_catena",
    "TipoSpinottiProlunga": "tipo_spinotti_prolunga",
    "GuainaEtichettaProlunga": "guaina_etichetta_prolunga",
    "GuainaEtichettaScheda": "guaina_etichetta_scheda",
    "PoliDc": "poli_dc",
    "TipoSpinottoOutCatena": "tipo_spinotto_out_catena",
    "TipoSpinottoInOutProlunga": "tipo_spinotto_in_out_prolunga",
    "Note": "note",
}

MAPPA_POWER = {
    "Alimentazione": "alimentazione",
    "CanaliTot": "canali_tot",
    "AmpereMaxCanale": "ampere_max_canale",
    "AmpereMaxBank": "ampere_max_bank",
    "TipoSpina": "tipo_spina",
    "QtaSpine": "qta_spine",
    "Ampere": "ampere",
    "Altezza": "altezza",
    "Larghezza": "larghezza",
    "NumeroAlimentatori": "numero_alimentatori",
    "Alimentatore1WattAmp": "alimentatore_1_watt_amp",
    "Alimentatore2WattAmp": "alimentatore_2_watt_amp",
    "BulbiPerCanale": "bulbi_per_canale",
    "WattXBulbo": "watt_x_bulbo",
    "WattXCanale": "watt_x_canale",
    "CanaliXBank": "canali_x_bank",
    "WattXBank": "watt_x_bank",
    "BankXScheda": "bank_x_scheda",
    "TotWattXScheda": "tot_watt_x_scheda",
    "TotWatt": "tot_watt",
    "TotAmpere": "tot_ampere",
}

CAMPI_TESTO_ALIMENTAZIONE = {
    "alimentazione", "canali_tot", "ampere_max_canale", "ampere_max_bank", "tipo_spina",
    "qta_spine", "ampere", "numero_alimentatori", "alimentatore_1_watt_amp",
    "alimentatore_2_watt_amp", "bulbi_per_canale", "canali_x_bank", "bank_x_scheda",
    "tot_watt", "tot_ampere",
}


def _rimappa(sorgente: dict, mappa: dict) -> dict:
    risultato = {}
    for chiave_originale, chiave_nuova in mappa.items():
        if chiave_originale in sorgente:
            risultato[chiave_nuova] = sorgente[chiave_originale]
    return risultato


def importa() -> None:
    with open(JSON_PATH, encoding="utf-8") as f:
        dati = json.load(f)

    esistenti = {(s["tipo"], s["identificativo"]) for s in db.get_schede()}

    importate = 0
    for voce in dati["schede"]:
        header = _rimappa(voce["header"], MAPPA_HEADER)
        header.setdefault("ordine_pagina", 0)
        chiave = (header.get("tipo"), header.get("identificativo"))
        if chiave in esistenti:
            print(f"Scheda gia' presente, salto: {chiave}")
            continue

        scheda_id = db.add_scheda(**header)

        canali = [_rimappa(c, MAPPA_CANALE) for c in voce.get("channels", [])]
        if canali:
            db.set_canali(scheda_id, canali)

        power_grezzo = _rimappa(voce.get("power", {}), MAPPA_POWER)
        if power_grezzo:
            power = {}
            for chiave_campo, valore in power_grezzo.items():
                if chiave_campo not in CAMPI_TESTO_ALIMENTAZIONE and valore is not None:
                    try:
                        valore = float(valore)
                    except (TypeError, ValueError):
                        pass
                power[chiave_campo] = valore
            db.set_alimentazione(scheda_id, **power)

        note = voce.get("notes", [])
        if note:
            db.set_note_scheda(scheda_id, note)

        importate += 1

    memo = dati.get("memo_generale", [])
    db.set_memo_generale(memo)

    print(f"Import completato: {importate} schede nuove, {len(memo)} memo generali")


if __name__ == "__main__":
    importa()
